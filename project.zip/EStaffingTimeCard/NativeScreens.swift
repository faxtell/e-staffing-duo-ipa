import SwiftUI
import WebKit

// Native front-end.  The single official WKWebView remains mounted behind it;
// the bridge sends only explicitly allowed UI field values and choice indices.
struct NativeApplicationScreen: View {
    @ObservedObject var model: NativeNavigationModel
    var body: some View {
        Group {
            if model.nativeSettingsOpen {
                NativePreferencesScreen(model:model)
            } else {
                switch model.page {
                case "login": NativeLoginScreen(model:model)
                case "home": NativeHomeScreen(model:model)
                case "daily": NativeDailyScreen(model:model)
                case "close": NativeClosingScreen(model:model)
                default: EmptyView()
                }
            }
        }
        .accessibilityIdentifier("native-main-content")
    }
}

private struct NativeSurface<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading,spacing:12) {
            Text(title).font(.headline)
            content
        }
        .frame(maxWidth:.infinity,alignment:.leading)
        .padding(16)
        .background(Color(uiColor:.secondarySystemGroupedBackground),in:RoundedRectangle(cornerRadius:20))
    }
}

struct NativeHomeScreen: View {
    @ObservedObject var model: NativeNavigationModel
    @AppStorage("etc-duo-v296-salary.enabled") private var salaryEnabled = false
    @AppStorage("etc-duo-v296-salary.hourlyJPY") private var rate = 0
    @AppStorage("etc-duo-v296-salary.premium") private var premium = true
    @State private var salaryHidden = false

    private var salaryValid: Bool {
        guard let worked=model.summary["worked"] as? Int,
              let valid=model.summary["valid"] as? Int else{return false}
        return valid == worked && model.summary["minutes"] is Int && model.summary["overtimeMinutes"] is Int
    }
    private var payroll: (Int,Int,Int) {
        let mins=model.summary["minutes"] as? Int ?? 0
        let overtime=model.summary["overtimeMinutes"] as? Int ?? 0
        let hourly=Double(rate)
        let base=Double(mins)*hourly/60.0
        let uplift=premium ? Double(overtime)*hourly/60.0*0.25 : 0
        let overtimePay=Double(overtime)*hourly/60.0+uplift
        return (Int((base+uplift).rounded()),Int(overtimePay.rounded()),Int(uplift.rounded()))
    }
    private func currency(_ amount:Int)->String {amount.formatted(.currency(code:"JPY").precision(.fractionLength(0)))}
    private func readable(_ number:Int)->String { salaryHidden ? "•••••" : currency(number) }
    private func minutes(_ number:Int)->String {"\(number/60)時間\(String(format:"%02d",number%60))分"}
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:16) {
                Text("ホーム").font(.largeTitle.bold())
                if let start=model.summary["start"] as? String,let end=model.summary["end"] as? String {
                    Text("\(start) 〜 \(end)").font(.caption).foregroundStyle(.secondary)
                }
                NativeSurface(title:"勤務ダッシュボード") {
                    LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:16) {
                        metric("勤務日数",value:(model.summary["worked"] as? Int).map{"\($0)日"} ?? "—",icon:"calendar")
                        metric("記録なし",value:(model.summary["empty"] as? Int).map{"\($0)日"} ?? "—",icon:"calendar.badge.exclamationmark")
                        metric("実労働",value:salaryValid ? minutes(model.summary["minutes"] as? Int ?? 0) : "—",icon:"clock")
                        metric("残業",value:salaryValid ? minutes(model.summary["overtimeMinutes"] as? Int ?? 0) : "—",icon:"moon.stars")
                    }
                }
                if salaryEnabled && rate > 0 {
                    NativeSurface(title:"給与目安") {
                        HStack(alignment:.firstTextBaseline) {
                            VStack(alignment:.leading,spacing:6) {
                                Text(salaryValid ? readable(payroll.0) : "—").font(.system(.title,design:.rounded,weight:.bold))
                                Text("給与の概算").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button { salaryHidden.toggle() } label: {
                                Image(systemName:salaryHidden ? "eye.slash" : "eye").font(.title3)
                            }.accessibilityLabel(salaryHidden ? "金額を表示" : "金額を隠す")
                        }
                        Divider()
                        HStack {Text("残業代");Spacer();Text(salaryValid ? readable(payroll.1) : "—").bold()}
                        HStack {Text("うち割増分");Spacer();Text(salaryValid ? readable(payroll.2) : "—").bold()}
                    }
                }
                NativeSurface(title:"勤怠管理") {
                    Button {model.navigate("daily")} label: {
                        Label("日々勤怠を入力",systemImage:"clock.badge.checkmark").frame(maxWidth:.infinity,alignment:.leading)
                    }.buttonStyle(.borderedProminent).controlSize(.large)
                    Button {model.navigate("close")} label: {
                        Label("締め申請・勤務記録",systemImage:"calendar.badge.clock").frame(maxWidth:.infinity,alignment:.leading)
                    }.buttonStyle(.bordered).controlSize(.large)
                }
            }.padding(16).frame(maxWidth:750)
                .frame(maxWidth:.infinity)
        }
    }
    private func metric(_ title:String,value:String,icon:String)->some View {
        VStack(alignment:.leading,spacing:8) {
            Label(title,systemImage:icon).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.system(.title3,design:.rounded,weight:.semibold)).minimumScaleFactor(0.75).lineLimit(1)
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
}

struct NativeDailyScreen: View {
    @ObservedObject var model: NativeNavigationModel
    @State private var confirmedApply = false
    private func field(_ name:String)->String {model.nativeDailyFields[name] ?? ""}
    private func timeValue(_ name:String)->Date {
        let value=field(name)
        let hour=value.count==4 ? Int(value.prefix(2)) ?? 9 : (name=="startTime" ? 9 : 18)
        let minute=value.count==4 ? Int(value.suffix(2)) ?? 0 : 0
        return Calendar.current.date(from: DateComponents(year:2001,month:1,day:1,hour:hour,minute:minute)) ?? Date()
    }
    private func setTime(_ name:String,_ date:Date) {
        let comps=Calendar.current.dateComponents([.hour,.minute],from:date)
        let value=String(format:"%02d%02d",comps.hour ?? 0,comps.minute ?? 0)
        model.nativeFormAction(["kind":"field","name":name,"value":value])
    }
    private var saveText:String {
        switch model.nativeSaveState {
        case "pending":return "変更を検出 · 自動一時保存待ち"
        case "sending":return "一時保存中…"
        case "verify":return "送信後の結果確認が必要です"
        case "local":return "入力を保持中 · 一時保存条件を確認してください"
        case "error":return "自動保存できませんでした"
        default:return "入力後、変更が落ち着くと自動で一時保存"
        }
    }
    private func minuteOfDay(_ raw: String) -> Int? {
        guard raw.count == 4, let hour = Int(raw.prefix(2)),
              let minute = Int(raw.suffix(2)), hour < 24, minute < 60 else { return nil }
        return hour * 60 + minute
    }
    private var elapsedMinutes: Int? {
        guard let start = minuteOfDay(field("startTime")),
              let end = minuteOfDay(field("endTime")) else { return nil }
        let elapsed = (end - start + 1440) % 1440
        return elapsed > 0 && elapsed <= 960 ? elapsed : nil
    }
    private var recommendedRestMinutes: Int? {
        guard let span = elapsedMinutes else { return nil }
        // Conservative guidance based on time between start and end. The legal
        // threshold itself depends on ACTUAL working time, not elapsed span.
        return span > 480 ? 60 : span > 360 ? 45 : 0
    }
    private var enteredRestMinutes: Int? {
        let raw = field("rstTime").trimmingCharacters(in: .whitespacesAndNewlines)
        if raw.isEmpty { return nil }
        if let value = Int(raw), value >= 0, value <= 960 { return value }
        let parts = raw.split(separator: ":")
        if parts.count == 2, let h = Int(parts[0]), let m = Int(parts[1]),
           h >= 0, h <= 16, m >= 0, m < 60 { return h * 60 + m }
        return nil
    }
    private var actualWorkMinutes: Int? {
        guard let span = elapsedMinutes, let rest = enteredRestMinutes,
              rest <= span else { return nil }
        return span - rest
    }
    private var legalMinimumMinutes: Int? {
        guard let worked = actualWorkMinutes else { return nil }
        return worked > 480 ? 60 : worked > 360 ? 45 : 0
    }
    private func duration(_ total: Int) -> String {
        total % 60 == 0 ? "\(total / 60)時間" : "\(total / 60)時間\(total % 60)分"
    }
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:15) {
                Text("日々勤怠").font(.largeTitle.bold())
                if !model.nativeDayTitle.isEmpty {Text(model.nativeDayTitle).font(.subheadline).foregroundStyle(.secondary)}
                NativeSurface(title:"勤務時間") {
                    HStack(spacing:12) {
                        timeItem("開始",name:"startTime")
                        timeItem("終了",name:"endTime")
                    }
                }
                NativeSurface(title:"区分") {
                    choices(model.nativeCategory,group:"category")
                }
                NativeSurface(title:"就業場所") {
                    choices(model.nativeWorkplace,group:"workplace")
                }
                NativeSurface(title:"休憩・実労働") {
                    HStack(alignment: .top, spacing: 12) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("休憩の目安").font(.caption).foregroundStyle(.secondary)
                            Text(recommendedRestMinutes.map { "\($0)分" } ?? "—")
                                .font(.title3.bold())
                        }
                        Spacer()
                        VStack(alignment: .trailing, spacing: 4) {
                            Text("実労働時間").font(.caption).foregroundStyle(.secondary)
                            Text(actualWorkMinutes.map(duration) ?? "—")
                                .font(.title3.bold())
                        }
                    }
                    fieldEntry("実際の休憩時間（分）",name:"rstTime")
                    if let required = legalMinimumMinutes, let entered = enteredRestMinutes,
                       required > entered {
                        Label("実労働時間に対する最低休憩は\(required)分です。取得した休憩を確認してください。",
                              systemImage:"exclamationmark.triangle.fill")
                            .font(.caption).foregroundStyle(.orange)
                    } else if let required = legalMinimumMinutes {
                        Label("実労働時間に対する法定最低休憩：\(required)分",
                              systemImage:"checkmark.circle")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button { model.nativeFormAction(["kind":"breakRecalculate"]) } label: {
                        Label("休憩の目安を入力",systemImage:"arrow.clockwise")
                    }.buttonStyle(.bordered)
                    Text("実際に取得した休憩時間に合わせて変更してください。")
                        .font(.caption2).foregroundStyle(.secondary)
                    if model.nativeDailyFields["nightRstTime"] != nil && !field("nightRstTime").isEmpty {
                        fieldEntry("深夜休憩",name:"nightRstTime")
                    }
                    fieldEntry("備考",name:"remark")
                }
                NativeSurface(title:"自動一時保存") {
                    Label(saveText,systemImage:model.nativeSaveState == "error" ? "exclamationmark.triangle" : "arrow.triangle.2.circlepath")
                        .font(.caption).foregroundStyle(.secondary)
                    if model.nativeCanSave {
                        Button("今すぐ一時保存") {model.nativeFormAction(["kind":"save"])}
                            .buttonStyle(.bordered).disabled(model.nativeSaveState == "sending")
                    }
                    Button { model.showOfficial = true } label: {
                        Label("詳細入力・申請へ",systemImage:"square.and.pencil")
                    }.buttonStyle(.borderedProminent).controlSize(.large)
                }
            }.padding(16).frame(maxWidth:750).frame(maxWidth:.infinity)
        }
    }
    private func timeItem(_ label:String,name:String)->some View {
        VStack(alignment:.leading,spacing:8) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            DatePicker("",selection:Binding(get:{timeValue(name)},set:{setTime(name,$0)}),displayedComponents:.hourAndMinute)
                .labelsHidden().datePickerStyle(.compact).frame(maxWidth:.infinity,alignment:.leading)
            Button {setTime(name,Date())} label: {Label("今",systemImage:"clock")}
                .buttonStyle(.bordered).controlSize(.small)
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
    @ViewBuilder private func choices(_ entries:[[String:Any]],group:String)->some View {
        if entries.isEmpty {Text("選択肢を読み込んでいます").font(.caption).foregroundStyle(.secondary)}
        else {
            LazyVGrid(columns:[GridItem(.adaptive(minimum:115),spacing:8)],spacing:8) {
                ForEach(Array(entries.enumerated()),id:\.offset) { index,entry in
                    let title=(entry["label"] as? String ?? "項目").prefix(40)
                    let selected=entry["selected"] as? Bool ?? false
                    Button {model.nativeFormAction(["kind":"choice","group":group,"index":entry["index"] as? Int ?? index])} label: {
                        HStack(spacing:6) {
                            if selected {Image(systemName:"checkmark.circle.fill")}
                            Text(String(title)).lineLimit(2).minimumScaleFactor(0.8)
                        }
                        .frame(maxWidth:.infinity,minHeight:38)
                    }
                    .buttonStyle(.bordered).tint(selected ? .accentColor : .secondary)
                    .disabled(entry["disabled"] as? Bool == true)
                }
            }
        }
    }
    private func fieldEntry(_ label:String,name:String)->some View {
        VStack(alignment:.leading,spacing:5) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            TextField(label,text:Binding(get:{field(name)},set:{model.nativeFormAction(["kind":"field","name":name,"value":$0])}))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)
        }
    }
}

// Native closing screen adapts to Duo outer/inner display WITHOUT loading
// a second official page. The same snapshot powers both layouts.
struct ClosingMonthData {
    let month: String
    let days: Int
    let firstWeekday: Int
    init(_ month: String) {
        self.month = month
        let parts = month.split(separator: "-")
        let y = parts.count == 2 ? Int(parts[0]) ?? 2026 : 2026
        let m = parts.count == 2 ? Int(parts[1]) ?? 1 : 1
        let calendar = Calendar(identifier: .gregorian)
        let date = calendar.date(from: DateComponents(year:y,month:m,day:1)) ?? Date()
        self.days = calendar.range(of:.day,in:.month,for:date)?.count ?? 30
        self.firstWeekday = calendar.component(.weekday,from:date) - 1
    }
    var title: String {
        let bits = month.split(separator:"-")
        guard bits.count == 2 else { return "勤務記録" }
        return "\(bits[0])年\(Int(bits[1]) ?? 1)月"
    }
    func key(_ day: Int) -> String { month + String(format:"-%02d",day) }
    func dateText(_ day: Int) -> String { "\(day)日" }
}

// For known dates, show official state only. Missing half-period data must
// stay '未取得' rather than being misreported as absent work.
private func closingStatus(_ record: NativeCalendarRecord?) -> String {
    guard let item=record else { return "未取得" }
    if !item.known { return "未取得" }
    if item.leave { return item.status.isEmpty ? "有給休暇" : item.status }
    if item.work { return item.status.isEmpty ? "勤務記録あり" : item.status }
    return item.holiday.isEmpty ? "記録なし" : item.holiday
}

private func closingColor(_ record: NativeCalendarRecord?) -> Color {
    guard let r=record, r.known else { return Color(uiColor:.tertiarySystemGroupedBackground) }
    if r.leave { return Color.purple.opacity(0.13) }
    if r.work { return Color.green.opacity(0.12) }
    return Color(uiColor:.secondarySystemGroupedBackground)
}

struct NativeClosingList: View {
    @ObservedObject var model: NativeNavigationModel
    let month: ClosingMonthData
    private let weekdayNames=["日","月","火","水","木","金","土"]
    var body: some View {
        LazyVStack(spacing: 9) {
            ForEach(1...month.days,id:\.self) { day in
                let key=month.key(day)
                let row=model.calendarRows[key]
                let w=(month.firstWeekday + day - 1) % 7
                Button { model.openCalendarDate(key) } label: {
                    HStack(alignment:.center,spacing:13) {
                        VStack(spacing:2) {
                            Text("\(day)").font(.title3.bold()).monospacedDigit()
                            Text(weekdayNames[w]).font(.caption2)
                                .foregroundStyle(w == 0 ? .red : w == 6 ? .blue : .secondary)
                        }.frame(width:39)
                        RoundedRectangle(cornerRadius:2)
                            .fill(row?.leave == true ? Color.purple : row?.work == true ? .green : .clear)
                            .frame(width:3)
                        VStack(alignment:.leading,spacing:5) {
                            Text(row?.work == true && !(row?.hours.isEmpty ?? true) ? row!.hours : closingStatus(row))
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.primary).lineLimit(2)
                            let detail=[row?.place ?? "",(row?.rest.isEmpty == false ? "休憩 \(row!.rest)" : ""),
                                        (row?.work == true ? row?.status ?? "" : "")]
                                .filter{ !$0.isEmpty }.joined(separator:" · ")
                            if !detail.isEmpty {
                                Text(detail).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                            } else if let holiday=row?.holiday,!holiday.isEmpty {
                                Text(holiday).font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Spacer(minLength:0)
                        Image(systemName:"chevron.right").font(.caption.weight(.semibold))
                            .foregroundStyle(.tertiary)
                    }
                    .padding(.horizontal,12).padding(.vertical,12)
                    .frame(maxWidth:.infinity,alignment:.leading)
                    .background(closingColor(row),in:RoundedRectangle(cornerRadius:14))
                }.buttonStyle(.plain)
                .accessibilityLabel("\(day)日 \(closingStatus(row)) \(row?.hours ?? "")")
            }
        }
        .accessibilityIdentifier("closing-outer-list")
    }
}

struct NativeClosingMonthCalendar: View {
    @ObservedObject var model: NativeNavigationModel
    let month: ClosingMonthData
    private let weekdays=["日","月","火","水","木","金","土"]
    private let cols=Array(repeating:GridItem(.flexible(minimum:0),spacing:6),count:7)
    var body:some View {
        LazyVGrid(columns:cols,spacing:7) {
            ForEach(0..<7,id:\.self) { w in
                Text(weekdays[w]).font(.caption.weight(.semibold))
                    .foregroundStyle(w == 0 ? Color.red : w == 6 ? Color.blue : Color.secondary)
                    .frame(maxWidth:.infinity)
            }
            ForEach(0..<month.firstWeekday,id:\.self) { _ in
                Color.clear.frame(minHeight:99)
            }
            ForEach(1...month.days,id:\.self) { day in
                let key=month.key(day)
                let row=model.calendarRows[key]
                Button { model.openCalendarDate(key) } label: {
                    VStack(alignment:.leading,spacing:5) {
                        Text("\(day)").font(.subheadline.weight(.bold))
                            .foregroundStyle((row?.holiday.isEmpty == false) ? Color.red : Color.primary)
                        if row?.work == true {
                            Text(row?.hours ?? "").font(.system(size:11,weight:.semibold))
                                .foregroundStyle(.primary).lineLimit(2)
                                .minimumScaleFactor(0.75)
                            if let detail=row?.place, !detail.isEmpty {
                                Text(detail).font(.system(size:9)).foregroundStyle(.secondary).lineLimit(1)
                            }
                            if let rest=row?.rest,!rest.isEmpty {
                                Text("休 \(rest)").font(.system(size:9)).foregroundStyle(.secondary).lineLimit(1)
                            }
                        } else {
                            Text(closingStatus(row)).font(.system(size:10,weight:.medium))
                                .foregroundStyle(.secondary).lineLimit(2)
                        }
                        Spacer(minLength:0)
                    }
                    .frame(maxWidth:.infinity,minHeight:93,maxHeight:93,alignment:.topLeading)
                    .padding(6)
                    .background(closingColor(row),in:RoundedRectangle(cornerRadius:11))
                    .overlay(RoundedRectangle(cornerRadius:11)
                        .strokeBorder(key == todayKey ? Color.accentColor : .clear,lineWidth:1.4))
                }.buttonStyle(.plain)
                    .accessibilityLabel("\(day)日 \(closingStatus(row)) \(row?.hours ?? "")")
            }
        }
        .accessibilityIdentifier("closing-inner-calendar")
    }
    private var todayKey:String {
        let c=Calendar.current.dateComponents([.year,.month,.day],from:Date())
        return String(format:"%04d-%02d-%02d",c.year ?? 0,c.month ?? 0,c.day ?? 0)
    }
}

struct NativeClosingScreen: View {
    @ObservedObject var model: NativeNavigationModel
    private func mins(_ m:Int) -> String { "\(m / 60)時間\(String(format:"%02d",m % 60))分" }
    private var leaveCount: Int {
        model.calendarRows.values.filter { $0.known && $0.leave }.count
    }
    var body: some View {
        GeometryReader { proxy in
            let expanded = proxy.size.width >= 690
            ScrollView {
                VStack(alignment:.leading,spacing:15) {
                    HStack {
                        VStack(alignment:.leading,spacing:4) {
                            Text("締め申請").font(.largeTitle.bold())
                            if model.calendarMonth.count == 7 {
                                Text(ClosingMonthData(model.calendarMonth).title)
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        Button { model.showOfficial=true } label: {
                            Label("申請・履歴",systemImage:"checkmark.seal")
                        }.buttonStyle(.borderedProminent)
                    }
                    if model.calendarMonth.count == 7 {
                        let month=ClosingMonthData(model.calendarMonth)
                        NativeSurface(title:"勤務状況・就業時間") {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing:12) {
                                closingMetric("出勤",(model.summary["worked"] as? Int).map{"\($0)日"} ?? "—")
                                closingMetric("年休","\(leaveCount)日")
                                closingMetric("実労働",(model.summary["minutes"] as? Int).map(mins) ?? "—")
                                closingMetric("残業",(model.summary["overtimeMinutes"] as? Int).map(mins) ?? "—")
                            }
                        }
                        if expanded {
                            NativeSurface(title:"月間カレンダー") {
                                NativeClosingMonthCalendar(model:model,month:month)
                            }
                        } else {
                            NativeSurface(title:"勤務記録") {
                                NativeClosingList(model:model,month:month)
                            }
                        }
                    } else {
                        ContentUnavailableView("勤務記録を読み込めませんでした",systemImage:"calendar.badge.exclamationmark",
                            description:Text("締め申請画面の読み込み後に表示されます"))
                        Button("申請・履歴へ") { model.showOfficial=true }
                            .buttonStyle(.borderedProminent)
                    }
                }
                .padding(16)
                .frame(maxWidth:expanded ? 1220 : 640)
                .frame(maxWidth:.infinity)
            }
            .accessibilityIdentifier(expanded ? "closing-inner-mode" : "closing-outer-mode")
        }
    }
    private func closingMetric(_ title:String,_ value:String) -> some View {
        VStack(alignment:.leading,spacing:4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.headline).monospacedDigit()
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
}

struct NativePreferencesScreen: View {
    @ObservedObject var model:NativeNavigationModel
    @AppStorage("etc-duo-v296-salary.enabled") private var showSalary=false
    @AppStorage("etc-duo-v296-salary.hourlyJPY") private var rate=0
    @AppStorage("etc-duo-v296-salary.premium") private var premium=true
    var body:some View {
        Form {
            Section("給与計算") {
                Toggle("給与目安を表示",isOn:$showSalary)
                HStack {Text("時給（円）");Spacer();TextField("2000",value:$rate,format:.number).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(maxWidth:130)}
                Toggle("8時間超の25%割増を含める",isOn:$premium)
            }
            Section("アプリ") {
                Button("詳細設定・通知") {
                    model.nativeSettingsOpen=false
                    model.showOfficial=true
                    model.webView?.evaluateJavaScript("window.__etcNativeNavigate?.('settings')",completionHandler:nil)
                }
                Button("ホームへ戻る") {model.navigate("home")}
            }
        }
        .onChange(of:showSalary){_,_ in model.publishNativeSalary()}
        .onChange(of:rate){_,_ in model.publishNativeSalary()}
        .onChange(of:premium){_,_ in model.publishNativeSalary()}
    }
}


struct NativeLoginScreen: View {
    @ObservedObject var model:NativeNavigationModel
    @State private var company="pasona"
    @State private var user=""
    @State private var password=""
    @State private var remember=true
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:20) {
                Label("WebTimeCard",systemImage:"checkmark.shield.fill")
                    .font(.headline).foregroundStyle(.tint)
                Text("ログイン").font(.largeTitle.bold())
                NativeSurface(title:"アカウント情報") {
                    TextField("企業ID",text:$company)
                        .textContentType(.organizationName).textFieldStyle(.roundedBorder)
                    TextField("ユーザーID",text:$user)
                        .textContentType(.username).textFieldStyle(.roundedBorder)
                    SecureField("パスワード",text:$password)
                        .textContentType(.password).textFieldStyle(.roundedBorder)
                    Toggle("ログイン情報をこのiPhoneに保存",isOn:$remember).font(.caption)
                    Button {
                        model.nativeLogin(["company":company,"user":user,"password":password,"remember":remember])
                    } label: {
                        Text("ログイン").frame(maxWidth:.infinity)
                    }.buttonStyle(.borderedProminent).controlSize(.large)
                        .disabled(user.isEmpty || password.isEmpty)
                    Button {model.faceIDLogin()} label: {
                        Label("Face ID / 端末認証でログイン",systemImage:"faceid")
                    }.buttonStyle(.bordered)
                }
                Button("別のログイン方法") {model.showOfficial=true}
                    .font(.caption)
            }.padding(22).frame(maxWidth:530).frame(maxWidth:.infinity)
        }
    }
}
