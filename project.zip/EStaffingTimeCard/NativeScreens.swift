import SwiftUI
import WebKit

// Native front-end.  The single official WKWebView remains mounted behind it;
// the bridge sends only explicitly allowed UI field values and choice indices.
struct NativeApplicationScreen: View {
    @ObservedObject var model: NativeNavigationModel
    var body: some View {
        Group {
            if model.nativeSettingsOpen {
                NativePreferencesScreen(model:model)
            } else {
                switch model.page {
                case "login": NativeLoginScreen(model:model)
                case "home": NativeHomeScreen(model:model)
                case "daily": NativeDailyScreen(model:model)
                case "close": NativeClosingScreen(model:model)
                default: EmptyView()
                }
            }
        }
        .accessibilityIdentifier("native-main-content")
    }
}

private struct NativeSurface<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading,spacing:12) {
            Text(title).font(.headline)
            content
        }
        .frame(maxWidth:.infinity,alignment:.leading)
        .padding(16)
        .background(Color(uiColor:.secondarySystemGroupedBackground),in:RoundedRectangle(cornerRadius:20))
    }
}

struct NativeHomeScreen: View {
    @ObservedObject var model: NativeNavigationModel
    @AppStorage("etc-duo-v296-salary.enabled") private var salaryEnabled = false
    @AppStorage("etc-duo-v296-salary.hourlyJPY") private var rate = 0
    @AppStorage("etc-duo-v296-salary.premium") private var premium = true
    @State private var salaryHidden = false

    private var salaryValid: Bool {
        guard let worked=model.summary["worked"] as? Int,
              let valid=model.summary["valid"] as? Int else{return false}
        return valid == worked && model.summary["minutes"] is Int && model.summary["overtimeMinutes"] is Int
    }
    private var payroll: (Int,Int,Int) {
        let mins=model.summary["minutes"] as? Int ?? 0
        let overtime=model.summary["overtimeMinutes"] as? Int ?? 0
        let hourly=Double(rate)
        let base=Double(mins)*hourly/60.0
        let uplift=premium ? Double(overtime)*hourly/60.0*0.25 : 0
        let overtimePay=Double(overtime)*hourly/60.0+uplift
        return (Int((base+uplift).rounded()),Int(overtimePay.rounded()),Int(uplift.rounded()))
    }
    private func currency(_ amount:Int)->String {amount.formatted(.currency(code:"JPY").precision(.fractionLength(0)))}
    private func readable(_ number:Int)->String { salaryHidden ? "•••••" : currency(number) }
    private func minutes(_ number:Int)->String {"\(number/60)時間\(String(format:"%02d",number%60))分"}
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:16) {
                Text("ホーム").font(.largeTitle.bold())
                if let start=model.summary["start"] as? String,let end=model.summary["end"] as? String {
                    Text("\(start) 〜 \(end)").font(.caption).foregroundStyle(.secondary)
                }
                NativeSurface(title:"勤務ダッシュボード") {
                    LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:16) {
                        metric("勤務日数",value:(model.summary["worked"] as? Int).map{"\($0)日"} ?? "—",icon:"calendar")
                        metric("記録なし",value:(model.summary["empty"] as? Int).map{"\($0)日"} ?? "—",icon:"calendar.badge.exclamationmark")
                        metric("実労働",value:salaryValid ? minutes(model.summary["minutes"] as? Int ?? 0) : "—",icon:"clock")
                        metric("残業",value:salaryValid ? minutes(model.summary["overtimeMinutes"] as? Int ?? 0) : "—",icon:"moon.stars")
                    }
                }
                if salaryEnabled && rate > 0 {
                    NativeSurface(title:"給与目安") {
                        HStack(alignment:.firstTextBaseline) {
                            VStack(alignment:.leading,spacing:6) {
                                Text(salaryValid ? readable(payroll.0) : "—").font(.system(.title,design:.rounded,weight:.bold))
                                Text("税引前の目安").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button { salaryHidden.toggle() } label: {
                                Image(systemName:salaryHidden ? "eye.slash" : "eye").font(.title3)
                            }.accessibilityLabel(salaryHidden ? "金額を表示" : "金額を隠す")
                        }
                        Divider()
                        HStack {Text("残業代");Spacer();Text(salaryValid ? readable(payroll.1) : "—").bold()}
                        HStack {Text("うち割増分");Spacer();Text(salaryValid ? readable(payroll.2) : "—").bold()}
                    }
                }
                NativeSurface(title:"勤怠管理") {
                    Button {model.navigate("daily")} label: {
                        Label("日々勤怠を入力",systemImage:"clock.badge.checkmark").frame(maxWidth:.infinity,alignment:.leading)
                    }.buttonStyle(.borderedProminent).controlSize(.large)
                    Button {model.navigate("close")} label: {
                        Label("月間カレンダー・締め申請",systemImage:"calendar.badge.clock").frame(maxWidth:.infinity,alignment:.leading)
                    }.buttonStyle(.bordered).controlSize(.large)
                }
            }.padding(16).frame(maxWidth:750)
                .frame(maxWidth:.infinity)
        }
    }
    private func metric(_ title:String,value:String,icon:String)->some View {
        VStack(alignment:.leading,spacing:8) {
            Label(title,systemImage:icon).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.system(.title3,design:.rounded,weight:.semibold)).minimumScaleFactor(0.75).lineLimit(1)
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
}

struct NativeDailyScreen: View {
    @ObservedObject var model: NativeNavigationModel
    @State private var confirmedApply = false
    private func field(_ name:String)->String {model.nativeDailyFields[name] ?? ""}
    private func timeValue(_ name:String)->Date {
        let value=field(name)
        let hour=value.count==4 ? Int(value.prefix(2)) ?? 9 : (name=="startTime" ? 9 : 18)
        let minute=value.count==4 ? Int(value.suffix(2)) ?? 0 : 0
        return Calendar.current.date(from: DateComponents(year:2001,month:1,day:1,hour:hour,minute:minute)) ?? Date()
    }
    private func setTime(_ name:String,_ date:Date) {
        let comps=Calendar.current.dateComponents([.hour,.minute],from:date)
        let value=String(format:"%02d%02d",comps.hour ?? 0,comps.minute ?? 0)
        model.nativeFormAction(["kind":"field","name":name,"value":value])
    }
    private var saveText:String {
        switch model.nativeSaveState {
        case "pending":return "変更を検出 · 自動一時保存待ち"
        case "sending":return "公式サイトへ一時保存中…"
        case "verify":return "送信後の結果確認が必要です"
        case "local":return "入力を保持中 · 一時保存条件を確認してください"
        case "error":return "自動保存できませんでした"
        default:return "変更後、入力が落ち着いたら自動で一時保存"
        }
    }
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:15) {
                Text("日々勤怠").font(.largeTitle.bold())
                if !model.nativeDayTitle.isEmpty {Text(model.nativeDayTitle).font(.subheadline).foregroundStyle(.secondary)}
                NativeSurface(title:"勤務時間") {
                    HStack(spacing:12) {
                        timeItem("開始",name:"startTime")
                        timeItem("終了",name:"endTime")
                    }
                }
                NativeSurface(title:"区分") {
                    choices(model.nativeCategory,group:"category")
                }
                NativeSurface(title:"就業場所") {
                    choices(model.nativeWorkplace,group:"workplace")
                }
                NativeSurface(title:"休憩・備考") {
                    fieldEntry("休憩（公式の入力形式）",name:"rstTime")
                    if model.nativeDailyFields["nightRstTime"] != nil && !field("nightRstTime").isEmpty {
                        fieldEntry("深夜休憩",name:"nightRstTime")
                    }
                    fieldEntry("備考",name:"remark")
                }
                NativeSurface(title:"自動一時保存") {
                    Label(saveText,systemImage:model.nativeSaveState == "error" ? "exclamationmark.triangle" : "arrow.triangle.2.circlepath")
                        .font(.caption).foregroundStyle(.secondary)
                    if model.nativeCanSave {
                        Button("今すぐ公式の一時保存") {model.nativeFormAction(["kind":"save"])}
                            .buttonStyle(.bordered).disabled(model.nativeSaveState == "sending")
                    }
                    Button { model.showOfficial = true } label: {
                        Label("公式フォームでその他の項目・申請を確認",systemImage:"rectangle.on.rectangle")
                    }.buttonStyle(.borderedProminent).controlSize(.large)
                }
            }.padding(16).frame(maxWidth:750).frame(maxWidth:.infinity)
        }
    }
    private func timeItem(_ label:String,name:String)->some View {
        VStack(alignment:.leading,spacing:8) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            DatePicker("",selection:Binding(get:{timeValue(name)},set:{setTime(name,$0)}),displayedComponents:.hourAndMinute)
                .labelsHidden().datePickerStyle(.compact).frame(maxWidth:.infinity,alignment:.leading)
            Button {setTime(name,Date())} label: {Label("今",systemImage:"clock")}
                .buttonStyle(.bordered).controlSize(.small)
        }.frame(maxWidth:.infinity,alignment:.leading)
    }
    @ViewBuilder private func choices(_ entries:[[String:Any]],group:String)->some View {
        if entries.isEmpty {Text("公式フォームで選択してください").font(.caption).foregroundStyle(.secondary)}
        else {
            LazyVGrid(columns:[GridItem(.adaptive(minimum:115),spacing:8)],spacing:8) {
                ForEach(Array(entries.enumerated()),id:\.offset) { index,entry in
                    let title=(entry["label"] as? String ?? "項目").prefix(40)
                    let selected=entry["selected"] as? Bool ?? false
                    Button {model.nativeFormAction(["kind":"choice","group":group,"index":entry["index"] as? Int ?? index])} label: {
                        HStack(spacing:6) {
                            if selected {Image(systemName:"checkmark.circle.fill")}
                            Text(String(title)).lineLimit(2).minimumScaleFactor(0.8)
                        }
                        .frame(maxWidth:.infinity,minHeight:38)
                    }
                    .buttonStyle(.bordered).tint(selected ? .accentColor : .secondary)
                    .disabled(entry["disabled"] as? Bool == true)
                }
            }
        }
    }
    private func fieldEntry(_ label:String,name:String)->some View {
        VStack(alignment:.leading,spacing:5) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            TextField(label,text:Binding(get:{field(name)},set:{model.nativeFormAction(["kind":"field","name":name,"value":$0])}))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .textFieldStyle(.roundedBorder)
        }
    }
}

struct NativeClosingScreen: View {
    @ObservedObject var model: NativeNavigationModel
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:14) {
                Text("締め申請").font(.largeTitle.bold())
                NativeSurface(title:"月間カレンダー") {
                    if model.calendarMonth.count == 7 {
                        NativeCalendarSidebar(model:model).frame(minHeight:410)
                    } else {
                        ContentUnavailableView("記録が未取得です",systemImage:"calendar",description:Text("公式の締め申請画面で読み込みが必要です"))
                    }
                }
                Button {model.showOfficial=true} label: {Label("公式画面で申請・確認",systemImage:"checkmark.seal")}
                    .buttonStyle(.borderedProminent).controlSize(.large)
            }.padding(16).frame(maxWidth:770).frame(maxWidth:.infinity)
        }
    }
}

struct NativePreferencesScreen: View {
    @ObservedObject var model:NativeNavigationModel
    @AppStorage("etc-duo-v296-salary.enabled") private var showSalary=false
    @AppStorage("etc-duo-v296-salary.hourlyJPY") private var rate=0
    @AppStorage("etc-duo-v296-salary.premium") private var premium=true
    var body:some View {
        Form {
            Section("給与計算") {
                Toggle("給与目安を表示",isOn:$showSalary)
                HStack {Text("時給（円）");Spacer();TextField("2000",value:$rate,format:.number).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(maxWidth:130)}
                Toggle("8時間超の25%割増を含める",isOn:$premium)
            }
            Section("アプリ") {
                Button("公式の設定・通知を開く") {
                    model.nativeSettingsOpen=false
                    model.showOfficial=true
                    model.webView?.evaluateJavaScript("window.__etcNativeNavigate?.('settings')",completionHandler:nil)
                }
                Button("ホームへ戻る") {model.navigate("home")}
            }
        }
        .onChange(of:showSalary){_,_ in model.publishNativeSalary()}
        .onChange(of:rate){_,_ in model.publishNativeSalary()}
        .onChange(of:premium){_,_ in model.publishNativeSalary()}
    }
}


struct NativeLoginScreen: View {
    @ObservedObject var model:NativeNavigationModel
    @State private var company="pasona"
    @State private var user=""
    @State private var password=""
    @State private var remember=true
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:20) {
                Label("WebTimeCard",systemImage:"checkmark.shield.fill")
                    .font(.headline).foregroundStyle(.tint)
                Text("ログイン").font(.largeTitle.bold())
                NativeSurface(title:"アカウント情報") {
                    TextField("企業ID",text:$company)
                        .textContentType(.organizationName).textFieldStyle(.roundedBorder)
                    TextField("ユーザーID",text:$user)
                        .textContentType(.username).textFieldStyle(.roundedBorder)
                    SecureField("パスワード",text:$password)
                        .textContentType(.password).textFieldStyle(.roundedBorder)
                    Toggle("ログイン情報をこのiPhoneに保存",isOn:$remember).font(.caption)
                    Button {
                        model.nativeLogin(["company":company,"user":user,"password":password,"remember":remember])
                    } label: {
                        Text("ログイン").frame(maxWidth:.infinity)
                    }.buttonStyle(.borderedProminent).controlSize(.large)
                        .disabled(user.isEmpty || password.isEmpty)
                    Button {model.faceIDLogin()} label: {
                        Label("Face ID / 端末認証でログイン",systemImage:"faceid")
                    }.buttonStyle(.bordered)
                }
                Button("公式ログイン画面を表示") {model.showOfficial=true}
                    .font(.caption)
            }.padding(22).frame(maxWidth:530).frame(maxWidth:.infinity)
        }
    }
}
