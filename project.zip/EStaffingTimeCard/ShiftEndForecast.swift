import Foundation

/// A display-only estimated clock-out time. Never mutates the official form.
enum ShiftEndForecast {
    static func endTime(startHHmm: String, netMinutes: Int, breakMinutes: Int) -> String? {
        guard startHHmm.count == 4,
              startHHmm.allSatisfy({ $0.isNumber }),
              let hour = Int(startHHmm.prefix(2)),
              let minute = Int(startHHmm.suffix(2)),
              hour >= 0, hour < 24, minute >= 0, minute < 60,
              netMinutes >= 0, netMinutes <= 900,
              breakMinutes >= 0, breakMinutes <= 240 else { return nil }
        let total = hour * 60 + minute + netMinutes + breakMinutes
        let clock = String(format: "%02d:%02d", (total / 60) % 24, total % 60)
        return total >= 1440 ? "翌日 " + clock : clock
    }
}
