import SwiftUI

@main
struct EStaffingTimeCardApp: App {
    var body: some Scene {
        WindowGroup {
            TimeCardView()
        }
    }
}
