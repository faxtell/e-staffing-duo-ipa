import Foundation
import Security

/// Opt-in login form credentials. Never stores a session token or attendance data.
struct TimeCardCredential: Codable {
    let companyID: String
    let userID: String
    let password: String
}

enum CredentialVault {
    private static let service = "jp.personal.timecard.secure-signin.v2"
    private static let account = "official-e-staffing-login"

    static func read() -> TimeCardCredential? {
        var query = baseQuery()
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return try? JSONDecoder().decode(TimeCardCredential.self, from: data)
    }

    static func exists() -> Bool { read() != nil }

    @discardableResult
    static func save(_ credential: TimeCardCredential) -> Bool {
        guard !credential.userID.isEmpty && !credential.password.isEmpty,
              let data = try? JSONEncoder().encode(credential) else { return false }
        var attributes = baseQuery()
        attributes[kSecValueData as String] = data
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let status = SecItemAdd(attributes as CFDictionary, nil)
        if status == errSecSuccess { return true }
        if status != errSecDuplicateItem { return false }
        return SecItemUpdate(baseQuery() as CFDictionary,
                             [kSecValueData as String: data] as CFDictionary) == errSecSuccess
    }

    @discardableResult
    static func delete() -> Bool {
        let status = SecItemDelete(baseQuery() as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }

    private static func baseQuery() -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }
}
