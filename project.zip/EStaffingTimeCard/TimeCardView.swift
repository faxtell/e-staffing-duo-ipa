import SwiftUI
import UIKit
import WebKit
import LocalAuthentication

/// A responsive WebKit shell around the official e-staffing mobile application.
/// No personal credential is stored unless the user explicitly selects the opt-in.
struct TimeCardView: View {
    var body: some View {
        OfficialTimeCardWebView()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(uiColor: .systemGroupedBackground))
        // Use the SwiftUI scene's available space, never UIScreen.main bounds.
        // Do not recreate WKWebView during fold/unfold or resize.
    }
}

struct OfficialTimeCardWebView: UIViewRepresentable {
    private static let home = URL(string: "https://m.e-staffing.ne.jp/s/")!

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        // Default persistent data store: do NOT use nonPersistent(), do NOT
        // clear cookies on launch, and do NOT recreate the view on rotations.
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true

        let controller = config.userContentController
        controller.add(context.coordinator, name: "etcCredentialBridge")

        // Early CSS suppresses the original UI before v4.5 transforms it.
        addScript("prepaint", to: controller, when: .atDocumentStart)
        addScript("duo-layout", to: controller, when: .atDocumentStart)
        addScript("e-staffing-native-v4.6", to: controller, when: .atDocumentEnd, isMain: true)
        addScript("credential-assistant", to: controller, when: .atDocumentEnd)

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .automatic
        webView.isOpaque = false
        webView.backgroundColor = .systemGroupedBackground
        webView.scrollView.backgroundColor = .systemGroupedBackground
        context.coordinator.webView = webView
        webView.load(URLRequest(url: Self.home))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        // No reload here: resizing/rotation/folding must preserve the web session.
    }

    private func addScript(_ filename: String,
                           to controller: WKUserContentController,
                           when timing: WKUserScriptInjectionTime,
                           isMain: Bool = false) {
        guard let url = Bundle.main.url(forResource: filename, withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8) else { return }
        let wrapped: String
        if isMain {
            wrapped = """
            try {\n\(source)\n} catch (error) { console.error('TimeCard design:', error); }
            finally { document.documentElement.removeAttribute('data-etc-native-preparing'); }
            """
        } else {
            wrapped = source
        }
        controller.addUserScript(WKUserScript(source: wrapped,
            injectionTime: timing, forMainFrameOnly: true))
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var webView: WKWebView?
        private var pending: TimeCardCredential?
        // One automatic attempt per app launch. This also prevents logging
        // users straight back in after an intentional LOGOUT.
        private var automaticSignInAttempted = false
        private var authenticationInProgress = false
        private var lastSubmissionWasAutomatic = false

        // The e-staffing service may redirect to URLs without /s/ (or to
        // another official e-staffing subdomain).  A redirect is NOT a tap.
        // Keep these HTTPS pages inside the WebView instead of sending users
        // to Safari during app launch or login.
        private func isTrustedWebURL(_ url: URL) -> Bool {
            guard url.scheme?.lowercased() == "https",
                  let host = url.host?.lowercased() else { return false }
            return host == "e-staffing.ne.jp" || host.hasSuffix(".e-staffing.ne.jp")
        }

        // Keychain credentials must ONLY be read/filled on the mobile
        // WebTimeCard pages, even if other company pages are shown in-app.
        private func isOfficialPage(_ url: URL) -> Bool {
            guard isTrustedWebURL(url),
                  url.host?.lowercased() == "m.e-staffing.ne.jp" else { return false }
            return url.path == "/s" || url.path == "/s/" || url.path.hasPrefix("/s/")
        }

        private func isExternalUserLink(_ action: WKNavigationAction) -> Bool {
            action.navigationType == .linkActivated
        }

        private func mayOpenExternally(_ url: URL) -> Bool {
            guard let scheme = url.scheme?.lowercased() else { return false }
            return ["https", "http", "tel", "mailto"].contains(scheme)
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            // about:blank is a legitimate WebKit placeholder while a page loads.
            if url.scheme?.lowercased() == "about" {
                decisionHandler(.allow)
                return
            }
            if isTrustedWebURL(url) {
                decisionHandler(.allow)
                return
            }

            // For target=_blank, let WKUIDelegate decide.  It opens only a
            // link the user explicitly clicked, never a scripted popup.
            if navigationAction.targetFrame == nil {
                decisionHandler(.allow)
                return
            }

            // Critical v2.3 change: an automatic cross-domain redirect or a
            // JavaScript navigation MUST NOT open Safari on its own.
            if isExternalUserLink(navigationAction) && mayOpenExternally(url) {
                UIApplication.shared.open(url)
            } else {
                NSLog("TimeCard: blocked automatic offsite navigation to host: %@", url.host ?? "unknown")
            }
            decisionHandler(.cancel)
        }

        func webView(_ webView: WKWebView,
                     createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction,
                     windowFeatures: WKWindowFeatures) -> WKWebView? {
            guard navigationAction.targetFrame == nil,
                  let url = navigationAction.request.url else { return nil }
            if isTrustedWebURL(url) {
                // Stay in the SAME WebView and retain cookies/session.
                webView.load(URLRequest(url: url))
            } else if isExternalUserLink(navigationAction) && mayOpenExternally(url) {
                // Explicit user tap on FAQ or other outside link.
                UIApplication.shared.open(url)
            } else {
                NSLog("TimeCard: ignored automatic popup to host: %@", url.host ?? "unknown")
            }
            return nil
        }

        func userContentController(_ controller: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "etcCredentialBridge",
                  message.frameInfo.isMainFrame,
                  let currentURL = webView?.url,
                  isOfficialPage(currentURL),
                  let payload = message.body as? [String: Any],
                  let action = payload["action"] as? String else { return }
            switch action {
            case "status":
                status()
            case "candidate":
                // Store in memory only until the official server returns a home screen.
                guard let userID = payload["userID"] as? String,
                      let password = payload["password"] as? String,
                      !userID.isEmpty, !password.isEmpty,
                      userID.count <= 128, password.count <= 512 else { return }
                let companyID = payload["companyID"] as? String ?? "pasona"
                pending = TimeCardCredential(companyID: companyID, userID: userID, password: password)
            case "restore":
                restoreAfterDeviceAuthentication()
            case "authenticateAndLogin":
                // User-initiated retry is available after cancellation/errors.
                authenticateAndSubmitLogin()
            case "delete":
                confirmDelete()
            default:
                return
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            guard let url = webView.url, isOfficialPage(url) else { return }
            // After a login POST, the URL can still be /s/TMSLGN01/ even
            // though the returned page contains the staff-menu form.
            let test = """
            ({home: !!document.querySelector('form[name="TMSMNU01ActionForm"]'),
              login: !!document.querySelector('form[name="TMSLGN01ActionForm"]')})
            """
            webView.evaluateJavaScript(test) { [weak self, weak webView] result, error in
                guard let self = self, let webView = webView,
                      self.webView === webView,
                      error == nil, let state = result as? [String: Bool] else { return }
                if state["home"] == true {
                    if let candidate = self.pending { _ = CredentialVault.save(candidate) }
                    self.pending = nil
                    self.lastSubmissionWasAutomatic = false
                    // Respect explicit logout later in the same app session.
                    self.automaticSignInAttempted = true
                } else if state["login"] == true {
                    if self.pending != nil {
                        self.pending = nil  // Never retry incorrect credentials automatically.
                        if self.lastSubmissionWasAutomatic {
                            self.status("自動ログインできませんでした。ID・パスワードを確認するか、手動でログインしてください。")
                        }
                        self.lastSubmissionWasAutomatic = false
                    } else if !self.automaticSignInAttempted,
                              !self.authenticationInProgress,
                              CredentialVault.exists() {
                        self.automaticSignInAttempted = true
                        self.authenticateAndSubmitLogin()
                    }
                }
            }
        }

        // A saved account means the user explicitly opted in on a previous
        // successful login. Device-owner authentication is still required
        // before any password is supplied to the official login form.
        private func authenticateAndSubmitLogin() {
            guard !authenticationInProgress, CredentialVault.exists() else {
                status("保存済みのログイン情報がありません。")
                return
            }
            guard let view = webView,
                  let url = view.url, isOfficialPage(url) else { return }
            authenticationInProgress = true
            let context = LAContext()
            context.localizedCancelTitle = "キャンセル"
            var authError: NSError?
            guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &authError) else {
                authenticationInProgress = false
                status("Face ID／Touch IDまたは端末パスコードを設定し、手動でログインしてください。")
                return
            }
            context.evaluatePolicy(.deviceOwnerAuthentication,
                                   localizedReason: "保存したe-staffingアカウントでログインします") { [weak self] success, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.authenticationInProgress = false
                    guard success else {
                        self.status("本人確認がキャンセルされました。手動ログインも利用できます。")
                        return
                    }
                    guard let activeView = self.webView,
                          activeView === view,
                          let url = activeView.url, self.isOfficialPage(url),
                          let credential = CredentialVault.read() else {
                        self.status("ログイン画面または保存情報を確認できませんでした。")
                        return
                    }
                    let payload: [String: String] = [
                        "companyID": credential.companyID,
                        "userID": credential.userID,
                        "password": credential.password
                    ]
                    guard let json = self.jsonLiteral(payload) else { return }
                    // Set pending before clicking submit. Login may navigate before
                    // JS messages reach the coordinator. Save only on menu success.
                    self.pending = credential
                    self.lastSubmissionWasAutomatic = true
                    activeView.evaluateJavaScript("window.__etcCredentialAutoSubmit?.(\(json))") { [weak self] result, error in
                        guard let self = self else { return }
                        if error == nil, let didSubmit = result as? Bool, !didSubmit {
                            self.pending = nil
                            self.lastSubmissionWasAutomatic = false
                            self.status("ログイン画面が変更されたため、自動ログインできませんでした。手動でログインしてください。")
                        }
                        // A navigation can cancel the JS completion callback
                        // even when the form POST has already been submitted.
                    }
                }
            }
        }

        private func status(_ detail: String? = nil) {
            guard let webView = webView else { return }
            let flag = CredentialVault.exists() ? "true" : "false"
            let textArg = detail.flatMap { jsonLiteral($0) } ?? "null"
            webView.evaluateJavaScript("window.__etcCredentialStatus?.(\(flag),\(textArg))", completionHandler: nil)
        }

        private func restoreAfterDeviceAuthentication() {
            guard CredentialVault.exists() else {
                status("保存されたログイン情報はありません。"); return
            }
            let context = LAContext()
            context.localizedCancelTitle = "キャンセル"
            var error: NSError?
            guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
                status("端末のFace IDまたはパスコードを設定してから利用してください。"); return
            }
            context.evaluatePolicy(.deviceOwnerAuthentication,
                                   localizedReason: "保存したe-staffingのログイン情報を入力します") { [weak self] success, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    guard success else {
                        self.status("認証がキャンセルされたため、入力していません。"); return
                    }
                    guard let credential = CredentialVault.read(),
                          let view = self.webView,
                          let currentURL = view.url,
                          self.isOfficialPage(currentURL) else { return }
                    let data: [String: String] = [
                        "companyID": credential.companyID,
                        "userID": credential.userID,
                        "password": credential.password
                    ]
                    guard let json = self.jsonLiteral(data) else { return }
                    view.evaluateJavaScript("window.__etcCredentialApply?.(\(json))", completionHandler: nil)
                }
            }
        }

        private func confirmDelete() {
            guard let view = webView,
                  let presenter = view.window?.rootViewController else { return }
            let alert = UIAlertController(title: "保存情報を削除", message: "このiPhoneに保存された企業ID・ユーザID・パスワードを削除します。公式サイトのセッションやCookieは削除しません。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "キャンセル", style: .cancel))
            alert.addAction(UIAlertAction(title: "削除", style: .destructive) { [weak self] _ in
                let ok = CredentialVault.delete()
                self?.status(ok ? "保存したログイン情報を削除しました。" : "削除に失敗しました。")
            })
            presenter.present(alert, animated: true)
        }

        private func jsonLiteral(_ object: Any) -> String? {
            guard let data = try? JSONSerialization.data(withJSONObject: object, options: [.fragmentsAllowed]),
                  let text = String(data: data, encoding: .utf8) else { return nil }
            return text
        }
    }
}
