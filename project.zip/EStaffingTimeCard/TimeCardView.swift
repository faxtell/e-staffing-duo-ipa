import SwiftUI
import UIKit
import WebKit
import LocalAuthentication
import UserNotifications

/// Native Liquid Glass bar above the persistent WebView. The web page owns
/// all official forms, routing URLs, and authentication state.
struct DuoCalendarDay: Identifiable {
    let id: String
    let status: String
    let kind: String
    let worked: Bool
    let leave: Bool
    let href: URL?
}

final class NativeNavigationModel: ObservableObject {
    @Published var page = "login"
    @Published var calendarDays: [DuoCalendarDay] = []
    @Published var periodStart = ""
    @Published var periodEnd = ""
    var summary: [String: Any] = [:]
    @Published var isVisible = false
    @Published var sheetOpen = false
    @Published var websiteTheme = "system"
    weak var webView: WKWebView?

    func openCalendarDate(_ day: DuoCalendarDay) {
        guard let url = day.href,
              url.scheme == "https", url.host == "m.e-staffing.ne.jp",
              url.path.hasPrefix("/s/"), let webView = webView else { return }
        webView.load(URLRequest(url: url))
    }

    func consumeCalendar(_ payload: [String: Any]) {
        guard let raw = payload["days"] as? [[String: Any]], raw.count <= 65,
              let start = payload["start"] as? String,
              let end = payload["end"] as? String,
              start.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil,
              end.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil else { return }
        let items: [DuoCalendarDay] = raw.compactMap { row in
            guard let date = row["date"] as? String,
                  date.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil else { return nil }
            let link = (row["href"] as? String).flatMap(URL.init(string:))
            let verified = (link?.scheme == "https" && link?.host == "m.e-staffing.ne.jp" && link?.path.hasPrefix("/s/") == true) ? link : nil
            return DuoCalendarDay(id: date, status: String((row["status"] as? String ?? "").prefix(35)),
                                  kind: String((row["kind"] as? String ?? "").prefix(8)),
                                  worked: row["work"] as? Bool == true,
                                  leave: row["leave"] as? Bool == true,
                                  href: verified)
        }
        guard !items.isEmpty else { return }
        periodStart = start
        periodEnd = end
        calendarDays = items
        if let aggregate = payload["summary"] as? [String: Any] {
            summary = aggregate
        }
    }

    func navigate(_ destination: String) {
        guard ["home", "daily", "close", "settings"].contains(destination),
              let webView = webView else { return }
        // Click the already-created official in-page links. No URLs or tokens
        // need to be reconstructed, and form submission remains site-owned.
        guard let payload = try? JSONSerialization.data(withJSONObject: destination, options: [.fragmentsAllowed]),
              let arg = String(data: payload, encoding: .utf8) else { return }
        webView.evaluateJavaScript("window.__etcNativeNavigate?.(\(arg))", completionHandler: nil)
    }

    func receive(_ info: [String: Any]) {
        guard let state = info["page"] as? String,
              ["login", "home", "daily", "close", "settings", "other"].contains(state) else { return }
        page = state
        isVisible = info["visible"] as? Bool == true
        sheetOpen = info["sheetOpen"] as? Bool == true
        if let theme = info["theme"] as? String,
           ["light", "dark", "system"].contains(theme) {
            websiteTheme = theme
        }
    }

    var preferredScheme: ColorScheme? {
        switch websiteTheme {
        case "dark": return .dark
        case "light": return .light
        default: return nil
        }
    }
}

/// v2.8: Use Apple's actual navigation toolbar instead of positioning a
/// hand-made capsule inside the content safe area.
///
/// iPhone Duo moves standard bottomBar toolbar items to the system-managed
/// vertical trailing bar on the cover screen and the unfolded landscape
/// display, leaving the camera/status region alone. On an unfolded portrait
/// screen (or conventional iPhone), the system keeps the horizontal bar.
/// Do not infer a fold state from a hard-coded screen width. Apple supports
/// intermediate folds, split view, and variable reserved regions.

/// Session-only calendar populated from the official closing-period table.
/// No fabricated day-specific URLs or saved authentication tokens.
struct DuoCalendarSidebar: View {
    @ObservedObject var navigation: NativeNavigationModel
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 7)

    private var months: [Date] {
        guard let first = navigation.calendarDays.first?.id,
              let last = navigation.calendarDays.last?.id else { return [] }
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        guard let a = formatter.date(from: first), let b = formatter.date(from: last) else { return [] }
        let cal = Calendar(identifier: .gregorian)
        var current = cal.date(from: cal.dateComponents([.year, .month], from: a))!
        let end = cal.date(from: cal.dateComponents([.year, .month], from: b))!
        var list: [Date] = []
        while current <= end && list.count < 3 {
            list.append(current)
            guard let next = cal.date(byAdding: .month, value: 1, to: current) else { break }
            current = next
        }
        return list
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                Text("勤務カレンダー").font(.title3.bold())
                Text("公式の締め申請画面から取得した日付のみ表示")
                    .font(.caption2).foregroundStyle(.secondary)
                if navigation.calendarDays.isEmpty {
                    ContentUnavailableView {
                        Label("カレンダー未取得", systemImage: "calendar")
                    } description: {
                        Text("締め申請を開くと、日付を選んで右側で勤怠を編集できます。")
                    } actions: {
                        Button("締め申請を開く") { navigation.navigate("close") }
                    }
                } else {
                    ForEach(months, id: \.self) { month in
                        monthGrid(month)
                    }
                    HStack(spacing: 12) {
                        Label("勤務記録", systemImage: "circle.fill").foregroundStyle(.green)
                        Label("有給", systemImage: "circle.fill").foregroundStyle(.purple)
                    }.font(.caption2)
                    Text("保存や申請は右側の公式フォームで行います。")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            .padding(14)
        }
        .frame(maxHeight: .infinity)
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .accessibilityIdentifier("duo-calendar-sidebar")
    }

    @ViewBuilder private func monthGrid(_ month: Date) -> some View {
        let calendar = Calendar(identifier: .gregorian)
        let comps = calendar.dateComponents([.year, .month], from: month)
        let days = calendar.range(of: .day, in: .month, for: month) ?? (1..<29)
        let offset = (calendar.component(.weekday, from: month) - 1)
        let byDate = Dictionary(uniqueKeysWithValues: navigation.calendarDays.map { ($0.id, $0) })
        VStack(alignment: .leading, spacing: 10) {
            Text("\(comps.year ?? 0)年\(comps.month ?? 0)月").font(.headline)
            LazyVGrid(columns: columns, spacing: 6) {
                ForEach(["日", "月", "火", "水", "木", "金", "土"], id: \.self) { name in
                    Text(name).font(.caption2).foregroundStyle(.secondary)
                }
                ForEach(0..<offset, id: \.self) { _ in Color.clear.frame(height: 41) }
                ForEach(Array(days), id: \.self) { dayNum in
                    let key = String(format: "%04d-%02d-%02d", comps.year ?? 0, comps.month ?? 0, dayNum)
                    let record = byDate[key]
                    Button {
                        if let record { navigation.openCalendarDate(record) }
                    } label: {
                        VStack(spacing: 3) {
                            Text("\(dayNum)").font(.caption.weight(.semibold))
                            Circle().fill(record?.leave == true ? Color.purple : (record?.worked == true ? .green : .clear))
                                .frame(width: 5, height: 5)
                        }
                        .frame(maxWidth: .infinity, minHeight: 41)
                        .background(key == Self.todayKey ? Color.accentColor.opacity(0.18) : Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 9))
                    }
                    .buttonStyle(.plain)
                    .disabled(record?.href == nil)
                    .opacity(record == nil ? 0.32 : 1)
                    .accessibilityLabel("\(key) \(record?.status ?? "")")
                }
            }
        }
    }

    private static var todayKey: String {
        let cal = Calendar.current
        let c = cal.dateComponents([.year, .month, .day], from: Date())
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }
}

struct TimeCardView: View {
    @StateObject private var navigation = NativeNavigationModel()

    private var showNavigation: Bool {
        navigation.isVisible && !navigation.sheetOpen
    }

    var body: some View {
        NavigationStack {
            // This remains the SAME WKWebView instance for the lifetime of the
            // screen, even if tabs change, the sheet opens, or Duo is folded.
            GeometryReader { geometry in
                HStack(spacing: 0) {
                    // Duo inner display: persistent calendar + official live form.
                    if geometry.size.width >= 700 && (navigation.page == "daily" || navigation.page == "close") {
                        DuoCalendarSidebar(navigation: navigation)
                            .frame(width: min(320, geometry.size.width * 0.40))
                        Divider()
                    }
                    OfficialTimeCardWebView(navigation: navigation)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(Color(uiColor: .systemGroupedBackground))
                }
            }
                .navigationBarTitleDisplayMode(.inline)
                .toolbar(.hidden, for: .navigationBar)
                .toolbar {
                    if showNavigation {
                        ToolbarItemGroup(placement: .bottomBar) {
                            nativeDestination("home", title: "ホーム", symbol: "house")
                            nativeDestination("daily", title: "日々勤怠", symbol: "calendar")
                            nativeDestination("close", title: "締め申請", symbol: "checkmark.rectangle")
                            nativeDestination("settings", title: "設定", symbol: "gearshape")
                        }
                    }
                }
        }
        .preferredColorScheme(navigation.preferredScheme)
        // Let iOS manage layout margins and reserved regions. Toolbar items
        // live OUTSIDE the WebView's safe area, as on Netflix and other Duo
        // native apps, rather than inside a custom ZStack/padded overlay.
    }

    @ViewBuilder
    private func nativeDestination(_ destination: String, title: String, symbol: String) -> some View {
        let selected = navigation.page == destination
        Button {
            navigation.navigate(destination)
        } label: {
            Label(title, systemImage: selected && destination == "home" ? "house.fill" :
                  selected && destination == "close" ? "checkmark.rectangle.fill" : symbol)
        }
        .tint(selected ? .accentColor : .primary)
        .accessibilityLabel(title)
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}

struct OfficialTimeCardWebView: UIViewRepresentable {
    @ObservedObject var navigation: NativeNavigationModel
    private static let home = URL(string: "https://m.e-staffing.ne.jp/s/")!

    func makeCoordinator() -> Coordinator { Coordinator(navigation: navigation) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        // Default persistent data store: do NOT use nonPersistent(), do NOT
        // clear cookies on launch, and do NOT recreate the view on rotations.
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true

        let controller = config.userContentController
        controller.add(context.coordinator, name: "etcCredentialBridge")
        controller.add(context.coordinator, name: "etcNavigationBridge")
        controller.add(context.coordinator, name: "etcProductivityBridge")

        // Early CSS suppresses the original UI before v4.5 transforms it.
        addScript("prepaint", to: controller, when: .atDocumentStart)
        addScript("duo-layout", to: controller, when: .atDocumentStart)
        addScript("e-staffing-native-v4.6", to: controller, when: .atDocumentEnd, isMain: true)
        addScript("break-autofill", to: controller, when: .atDocumentEnd)
        addScript("credential-assistant", to: controller, when: .atDocumentEnd)
        addScript("productivity", to: controller, when: .atDocumentEnd)

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .automatic
        webView.isOpaque = false
        webView.backgroundColor = .systemGroupedBackground
        webView.scrollView.backgroundColor = .systemGroupedBackground
        context.coordinator.webView = webView
        navigation.webView = webView
        webView.load(URLRequest(url: Self.home))
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        // No reload here: resizing/rotation/folding must preserve the web session.
    }

    private func addScript(_ filename: String,
                           to controller: WKUserContentController,
                           when timing: WKUserScriptInjectionTime,
                           isMain: Bool = false) {
        guard let url = Bundle.main.url(forResource: filename, withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8) else { return }
        let wrapped: String
        if isMain {
            wrapped = """
            try {\n\(source)\n} catch (error) { console.error('TimeCard design:', error); }
            finally { document.documentElement.removeAttribute('data-etc-native-preparing'); }
            """
        } else {
            wrapped = source
        }
        controller.addUserScript(WKUserScript(source: wrapped,
            injectionTime: timing, forMainFrameOnly: true))
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var webView: WKWebView?
        private let navigation: NativeNavigationModel

        init(navigation: NativeNavigationModel) {
            self.navigation = navigation
            super.init()
        }
        private var pending: TimeCardCredential?
        // One automatic attempt per app launch. This also prevents logging
        // users straight back in after an intentional LOGOUT.
        private var automaticSignInAttempted = false
        private var authenticationInProgress = false
        private var lastSubmissionWasAutomatic = false

        // The e-staffing service may redirect to URLs without /s/ (or to
        // another official e-staffing subdomain).  A redirect is NOT a tap.
        // Keep these HTTPS pages inside the WebView instead of sending users
        // to Safari during app launch or login.
        private func isTrustedWebURL(_ url: URL) -> Bool {
            guard url.scheme?.lowercased() == "https",
                  let host = url.host?.lowercased() else { return false }
            return host == "e-staffing.ne.jp" || host.hasSuffix(".e-staffing.ne.jp")
        }

        // Keychain credentials must ONLY be read/filled on the mobile
        // WebTimeCard pages, even if other company pages are shown in-app.
        private func isOfficialPage(_ url: URL) -> Bool {
            guard isTrustedWebURL(url),
                  url.host?.lowercased() == "m.e-staffing.ne.jp" else { return false }
            return url.path == "/s" || url.path == "/s/" || url.path.hasPrefix("/s/")
        }

        private func isExternalUserLink(_ action: WKNavigationAction) -> Bool {
            action.navigationType == .linkActivated
        }

        private func mayOpenExternally(_ url: URL) -> Bool {
            guard let scheme = url.scheme?.lowercased() else { return false }
            return ["https", "http", "tel", "mailto"].contains(scheme)
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            // about:blank is a legitimate WebKit placeholder while a page loads.
            if url.scheme?.lowercased() == "about" {
                decisionHandler(.allow)
                return
            }
            if isTrustedWebURL(url) {
                decisionHandler(.allow)
                return
            }

            // For target=_blank, let WKUIDelegate decide.  It opens only a
            // link the user explicitly clicked, never a scripted popup.
            if navigationAction.targetFrame == nil {
                decisionHandler(.allow)
                return
            }

            // Critical v2.3 change: an automatic cross-domain redirect or a
            // JavaScript navigation MUST NOT open Safari on its own.
            if isExternalUserLink(navigationAction) && mayOpenExternally(url) {
                UIApplication.shared.open(url)
            } else {
                NSLog("TimeCard: blocked automatic offsite navigation to host: %@", url.host ?? "unknown")
            }
            decisionHandler(.cancel)
        }

        func webView(_ webView: WKWebView,
                     createWebViewWith configuration: WKWebViewConfiguration,
                     for navigationAction: WKNavigationAction,
                     windowFeatures: WKWindowFeatures) -> WKWebView? {
            guard navigationAction.targetFrame == nil,
                  let url = navigationAction.request.url else { return nil }
            if isTrustedWebURL(url) {
                // Stay in the SAME WebView and retain cookies/session.
                webView.load(URLRequest(url: url))
            } else if isExternalUserLink(navigationAction) && mayOpenExternally(url) {
                // Explicit user tap on FAQ or other outside link.
                UIApplication.shared.open(url)
            } else {
                NSLog("TimeCard: ignored automatic popup to host: %@", url.host ?? "unknown")
            }
            return nil
        }

        func userContentController(_ controller: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            // This bridge transmits UI state only (page key/theme/modal flag),
            // never credentials or hidden form tokens.
            if message.name == "etcNavigationBridge" {
                guard message.frameInfo.isMainFrame,
                      let currentURL = webView?.url,
                      isOfficialPage(currentURL),
                      let payload = message.body as? [String: Any] else { return }
                navigation.receive(payload)
                return
            }
            if message.name == "etcProductivityBridge" {
                guard message.frameInfo.isMainFrame,
                      let currentURL = webView?.url, isOfficialPage(currentURL),
                      let payload = message.body as? [String: Any],
                      let action = payload["action"] as? String else { return }
                switch action {
                case "calendar":
                    guard currentURL.path.contains("TMSINP02") || navigation.page == "close" else { return }
                    navigation.consumeCalendar(payload)
                    publishDashboard()
                case "reminderStatus":
                    sendReminderStatus()
                case "reminder":
                    configureReminder(payload)
                default: break
                }
                return
            }
            guard message.name == "etcCredentialBridge",
                  message.frameInfo.isMainFrame,
                  let currentURL = webView?.url,
                  isOfficialPage(currentURL),
                  let payload = message.body as? [String: Any],
                  let action = payload["action"] as? String else { return }
            switch action {
            case "status":
                status()
            case "candidate":
                // Store in memory only until the official server returns a home screen.
                guard let userID = payload["userID"] as? String,
                      let password = payload["password"] as? String,
                      !userID.isEmpty, !password.isEmpty,
                      userID.count <= 128, password.count <= 512 else { return }
                let companyID = payload["companyID"] as? String ?? "pasona"
                pending = TimeCardCredential(companyID: companyID, userID: userID, password: password)
            case "restore":
                restoreAfterDeviceAuthentication()
            case "authenticateAndLogin":
                // User-initiated retry is available after cancellation/errors.
                authenticateAndSubmitLogin()
            case "delete":
                confirmDelete()
            default:
                return
            }
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            // Keep navigation visible while moving between signed-in pages.
            // Removing it on every navigation caused flashes/disappearing tabs.
            // The login page's document-end bridge will hide it when needed.
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            guard let url = webView.url, isOfficialPage(url) else { return }
            // After a login POST, the URL can still be /s/TMSLGN01/ even
            // though the returned page contains the staff-menu form.
            let test = """
            ({home: !!document.querySelector('form[name="TMSMNU01ActionForm"]'),
              login: !!document.querySelector('form[name="TMSLGN01ActionForm"]')})
            """
            publishDashboard()
            webView.evaluateJavaScript(test) { [weak self, weak webView] result, error in
                guard let self = self, let webView = webView,
                      self.webView === webView,
                      error == nil, let state = result as? [String: Bool] else { return }
                if state["home"] == true {
                    self.navigation.page = "home"
                    self.navigation.isVisible = true
                    if let candidate = self.pending { _ = CredentialVault.save(candidate) }
                    self.pending = nil
                    self.lastSubmissionWasAutomatic = false
                    // Respect explicit logout later in the same app session.
                    self.automaticSignInAttempted = true
                } else if state["login"] == true {
                    self.navigation.page = "login"
                    self.navigation.isVisible = false
                    self.navigation.calendarDays = []
                    self.navigation.summary = [:]
                    if self.pending != nil {
                        self.pending = nil  // Never retry incorrect credentials automatically.
                        if self.lastSubmissionWasAutomatic {
                            self.status("自動ログインできませんでした。ID・パスワードを確認するか、手動でログインしてください。")
                        }
                        self.lastSubmissionWasAutomatic = false
                    } else if !self.automaticSignInAttempted,
                              !self.authenticationInProgress,
                              CredentialVault.exists() {
                        self.automaticSignInAttempted = true
                        self.authenticateAndSubmitLogin()
                    }
                }
            }
        }

        // A saved account means the user explicitly opted in on a previous
        // successful login. Device-owner authentication is still required
        // before any password is supplied to the official login form.
        private func authenticateAndSubmitLogin() {
            guard !authenticationInProgress, CredentialVault.exists() else {
                status("保存済みのログイン情報がありません。")
                return
            }
            guard let view = webView,
                  let url = view.url, isOfficialPage(url) else { return }
            authenticationInProgress = true
            let context = LAContext()
            context.localizedCancelTitle = "キャンセル"
            var authError: NSError?
            guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &authError) else {
                authenticationInProgress = false
                status("Face ID／Touch IDまたは端末パスコードを設定し、手動でログインしてください。")
                return
            }
            context.evaluatePolicy(.deviceOwnerAuthentication,
                                   localizedReason: "保存したe-staffingアカウントでログインします") { [weak self] success, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.authenticationInProgress = false
                    guard success else {
                        self.status("本人確認がキャンセルされました。手動ログインも利用できます。")
                        return
                    }
                    guard let activeView = self.webView,
                          activeView === view,
                          let url = activeView.url, self.isOfficialPage(url),
                          let credential = CredentialVault.read() else {
                        self.status("ログイン画面または保存情報を確認できませんでした。")
                        return
                    }
                    let payload: [String: String] = [
                        "companyID": credential.companyID,
                        "userID": credential.userID,
                        "password": credential.password
                    ]
                    guard let json = self.jsonLiteral(payload) else { return }
                    // Set pending before clicking submit. Login may navigate before
                    // JS messages reach the coordinator. Save only on menu success.
                    self.pending = credential
                    self.lastSubmissionWasAutomatic = true
                    activeView.evaluateJavaScript("window.__etcCredentialAutoSubmit?.(\(json))") { [weak self] result, error in
                        guard let self = self else { return }
                        if error == nil, let didSubmit = result as? Bool, !didSubmit {
                            self.pending = nil
                            self.lastSubmissionWasAutomatic = false
                            self.status("ログイン画面が変更されたため、自動ログインできませんでした。手動でログインしてください。")
                        }
                        // A navigation can cancel the JS completion callback
                        // even when the form POST has already been submitted.
                    }
                }
            }
        }

        private func publishDashboard() {
            guard let view = webView, !navigation.summary.isEmpty,
                  let json = jsonLiteral(navigation.summary) else { return }
            view.evaluateJavaScript("window.__etcReceiveDashboard?.(\(json))", completionHandler: nil)
        }

        private let reminderPrefix = "etc-duo-v29."
        private func sendReminderStatus(message: String = "") {
            guard let view = webView else { return }
            func values(_ kind: String, _ defaultHour: Int, _ defaultMinute: Int, _ defaultDay: Int) -> [String: Any] {
                let key = "etc-duo-reminder-" + kind
                return ["enabled": UserDefaults.standard.bool(forKey: key + ".enabled"),
                        "hour": UserDefaults.standard.object(forKey: key + ".hour") as? Int ?? defaultHour,
                        "minute": UserDefaults.standard.object(forKey: key + ".minute") as? Int ?? defaultMinute,
                        "day": UserDefaults.standard.object(forKey: key + ".day") as? Int ?? defaultDay,
                        "message": message]
            }
            let payload: [String: Any] = ["weekday": values("weekday", 18, 30, 15),
                                          "close": values("close", 17, 0, 15)]
            guard let json = jsonLiteral(payload) else { return }
            view.evaluateJavaScript("window.__etcReminderStatus?.(\(json))", completionHandler: nil)
        }

        private func configureReminder(_ data: [String: Any]) {
            guard let kind = data["kind"] as? String, ["weekday", "close"].contains(kind),
                  let enabled = data["enabled"] as? Bool,
                  let hour = data["hour"] as? Int, (0...23).contains(hour),
                  let minute = data["minute"] as? Int, (0...59).contains(minute),
                  let day = data["day"] as? Int, (1...28).contains(day) else { return }
            let center = UNUserNotificationCenter.current()
            let prefix = reminderPrefix + kind + "."
            let ids = kind == "weekday" ? (2...6).map { prefix + String($0) } : [prefix + "monthly"]
            center.removePendingNotificationRequests(withIdentifiers: ids)
            let key = "etc-duo-reminder-" + kind
            guard enabled else {
                UserDefaults.standard.set(false, forKey: key + ".enabled")
                sendReminderStatus(message: "通知をオフにしました")
                return
            }
            center.requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] granted, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    guard granted else {
                        UserDefaults.standard.set(false, forKey: key + ".enabled")
                        self.sendReminderStatus(message: "通知の許可が必要です。設定アプリで許可してください。")
                        return
                    }
                    let texts = kind == "weekday"
                        ? ("今日の勤怠を確認", "勤務時間の入力・保存状況をe-staffingで確認してください。")
                        : ("締め申請の確認", "契約先の締め日と申請状況をe-staffingで確認してください。")
                    for id in ids {
                        let content = UNMutableNotificationContent()
                        content.title = texts.0
                        content.body = texts.1
                        content.sound = .default
                        var components = DateComponents()
                        components.hour = hour
                        components.minute = minute
                        if kind == "weekday" { components.weekday = Int(id.split(separator: ".").last ?? "2") }
                        else { components.day = day }
                        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
                        center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
                    }
                    UserDefaults.standard.set(true, forKey: key + ".enabled")
                    UserDefaults.standard.set(hour, forKey: key + ".hour")
                    UserDefaults.standard.set(minute, forKey: key + ".minute")
                    UserDefaults.standard.set(day, forKey: key + ".day")
                    self.sendReminderStatus(message: "通知を設定しました（申請状況の自動確認は行いません）")
                }
            }
        }

        private func status(_ detail: String? = nil) {
            guard let webView = webView else { return }
            let flag = CredentialVault.exists() ? "true" : "false"
            let textArg = detail.flatMap { jsonLiteral($0) } ?? "null"
            webView.evaluateJavaScript("window.__etcCredentialStatus?.(\(flag),\(textArg))", completionHandler: nil)
        }

        private func restoreAfterDeviceAuthentication() {
            guard CredentialVault.exists() else {
                status("保存されたログイン情報はありません。"); return
            }
            let context = LAContext()
            context.localizedCancelTitle = "キャンセル"
            var error: NSError?
            guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
                status("端末のFace IDまたはパスコードを設定してから利用してください。"); return
            }
            context.evaluatePolicy(.deviceOwnerAuthentication,
                                   localizedReason: "保存したe-staffingのログイン情報を入力します") { [weak self] success, _ in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    guard success else {
                        self.status("認証がキャンセルされたため、入力していません。"); return
                    }
                    guard let credential = CredentialVault.read(),
                          let view = self.webView,
                          let currentURL = view.url,
                          self.isOfficialPage(currentURL) else { return }
                    let data: [String: String] = [
                        "companyID": credential.companyID,
                        "userID": credential.userID,
                        "password": credential.password
                    ]
                    guard let json = self.jsonLiteral(data) else { return }
                    view.evaluateJavaScript("window.__etcCredentialApply?.(\(json))", completionHandler: nil)
                }
            }
        }

        private func confirmDelete() {
            guard let view = webView,
                  let presenter = view.window?.rootViewController else { return }
            let alert = UIAlertController(title: "保存情報を削除", message: "このiPhoneに保存された企業ID・ユーザID・パスワードを削除します。公式サイトのセッションやCookieは削除しません。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "キャンセル", style: .cancel))
            alert.addAction(UIAlertAction(title: "削除", style: .destructive) { [weak self] _ in
                let ok = CredentialVault.delete()
                self?.status(ok ? "保存したログイン情報を削除しました。" : "削除に失敗しました。")
            })
            presenter.present(alert, animated: true)
        }

        private func jsonLiteral(_ object: Any) -> String? {
            guard let data = try? JSONSerialization.data(withJSONObject: object, options: [.fragmentsAllowed]),
                  let text = String(data: data, encoding: .utf8) else { return nil }
            return text
        }
    }
}
