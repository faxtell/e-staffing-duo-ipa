/* Japanese public-holiday calendar. 2026/2027 dates from the Cabinet Office.
 * Outside these years, law-based estimates with computed equinoxes; do not use
 * as a substitute for company-specific closure or a real attendance record. */
(() => {
  'use strict';
  const official = {
    2026: {'01-01':'元日','01-12':'成人の日','02-11':'建国記念の日','02-23':'天皇誕生日','03-20':'春分の日','04-29':'昭和の日','05-03':'憲法記念日','05-04':'みどりの日','05-05':'こどもの日','05-06':'振替休日','07-20':'海の日','08-11':'山の日','09-21':'敬老の日','09-22':'国民の休日','09-23':'秋分の日','10-12':'スポーツの日','11-03':'文化の日','11-23':'勤労感謝の日'},
    2027: {'01-01':'元日','01-11':'成人の日','02-11':'建国記念の日','02-23':'天皇誕生日','03-21':'春分の日','03-22':'振替休日','04-29':'昭和の日','05-03':'憲法記念日','05-04':'みどりの日','05-05':'こどもの日','07-19':'海の日','08-11':'山の日','09-20':'敬老の日','09-23':'秋分の日','10-11':'スポーツの日','11-03':'文化の日','11-23':'勤労感謝の日'}
  };
  const pad=n=>String(n).padStart(2,'0');
  const nthMon=(y,m,n)=>1+(8-new Date(y,m-1,1).getDay())%7 +7*(n-1);
  const cache=new Map();
  function yearHolidays(year){
    if(cache.has(year))return cache.get(year);
    if(official[year]){const map=new Map(Object.entries(official[year]));cache.set(year,map);return map;}
    const map=new Map();
    if(year<2000 || year>2099){cache.set(year,map);return map;}
    const put=(m,d,name)=>map.set(`${pad(m)}-${pad(d)}`,name);
    const spring=Math.floor(20.8431+0.242194*(year-1980)-Math.floor((year-1980)/4));
    const autumn=Math.floor(23.2488+0.242194*(year-1980)-Math.floor((year-1980)/4));
    put(1,1,'元日');put(1,nthMon(year,1,2),'成人の日');put(2,11,'建国記念の日');put(2,23,'天皇誕生日');
    put(3,spring,'春分の日');put(4,29,'昭和の日');put(5,3,'憲法記念日');put(5,4,'みどりの日');put(5,5,'こどもの日');
    put(7,nthMon(year,7,3),'海の日');put(8,11,'山の日');put(9,nthMon(year,9,3),'敬老の日');
    put(9,autumn,'秋分の日');put(10,nthMon(year,10,2),'スポーツの日');put(11,3,'文化の日');put(11,23,'勤労感謝の日');
    if(year===2020||year===2021){
      map.delete(`${pad(7)}-${pad(nthMon(year,7,3))}`);map.delete('08-11');map.delete(`${pad(10)}-${pad(nthMon(year,10,2))}`);
      put(7,year===2020?23:22,'海の日');put(7,year===2020?24:23,'スポーツの日');put(8,year===2020?10:8,'山の日');
    }
    // Weekday bridge between two statutory holidays (e.g. Sep 22, 2026).
    for(let m=1;m<=12;m++)for(let d=2;d<=30;d++){
      const date=new Date(year,m-1,d);if(date.getMonth()!==m-1)continue;
      const key=`${pad(m)}-${pad(d)}`;if(map.has(key))continue;
      const prev=new Date(year,m-1,d-1),next=new Date(year,m-1,d+1);
      if(map.has(`${pad(prev.getMonth()+1)}-${pad(prev.getDate())}`) && map.has(`${pad(next.getMonth()+1)}-${pad(next.getDate())}`)) put(m,d,'国民の休日');
    }
    // Sunday statutory holiday -> the next working day (skipping holidays).
    for(const [key,name] of [...map]){
      if(name==='振替休日'||name==='国民の休日')continue;
      const [m,d]=key.split('-').map(Number);if(new Date(year,m-1,d).getDay()!==0)continue;
      let next=new Date(year,m-1,d+1);
      while(next.getFullYear()===year && map.has(`${pad(next.getMonth()+1)}-${pad(next.getDate())}`))next.setDate(next.getDate()+1);
      if(next.getFullYear()===year)put(next.getMonth()+1,next.getDate(),'振替休日');
    }
    cache.set(year,map);return map;
  }
  window.__etcJapanHolidayName = date => {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date)))return '';
    const year=Number(String(date).slice(0,4));
    return yearHolidays(year).get(String(date).slice(5)) || '';
  };
})();
