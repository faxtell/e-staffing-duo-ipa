/* Native credential assistant. Saved credentials: one authenticated sign-in per app launch. */
(() => {
  'use strict';
  if (location.origin !== 'https://m.e-staffing.ne.jp' || !location.pathname.startsWith('/s/')) return;
  const form = document.querySelector('form[name="TMSLGN01ActionForm"]');
  const bridge = window.webkit?.messageHandlers?.etcCredentialBridge;
  if (!form || !bridge || form.dataset.etcCredentialAssistant === '1') return;
  const company = form.querySelector('input[name="comid"]');
  const user = form.querySelector('input[name="userid"]');
  const pass = form.querySelector('input[name="password"]');
  if (!company || !user || !pass) return;
  form.dataset.etcCredentialAssistant = '1';

  const style = document.createElement('style');
  style.textContent = `
    .etc-credentials-panel { margin:14px 0 0; padding:13px 13px 2px; border-top:1px solid var(--e-line,rgba(60,60,67,.2)); color:var(--e-ink,#222); font-size:13px; }
    .etc-credentials-keep { display:flex; align-items:center; gap:10px; line-height:1.5; min-height:44px; }
    .etc-credentials-keep input { width:20px; height:20px; flex:none; accent-color:var(--e-blue,#007aff); }
    .etc-credentials-buttons { display:flex; gap:10px; flex-wrap:wrap; margin:10px 0 8px; }
    body.etc-native-v4 .etc-credentials-panel button { padding:9px 12px!important; background:var(--e-soft,#f1f1f5)!important; color:var(--e-blue,#007aff)!important; border-radius:12px; border:0; min-height:42px; font-size:14px!important; font-weight:650; }
    .etc-credentials-note { font-size:12px; color:var(--e-muted,#666); margin:7px 0 12px; line-height:1.5; }
  `;
  (document.head || document.documentElement).appendChild(style);

  const panel = document.createElement('div');
  panel.className = 'etc-credentials-panel';
  const label = document.createElement('label');
  label.className = 'etc-credentials-keep';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.id = 'etc-credentials-opt-in';
  const labelText = document.createElement('span');
  labelText.textContent = 'ログイン情報をこのiPhoneに安全に保存する';
  label.append(checkbox,labelText);
  const buttons = document.createElement('div'); buttons.className = 'etc-credentials-buttons';
  const restore = document.createElement('button'); restore.type='button'; restore.textContent = 'Face IDでログイン'; restore.hidden=true;
  const restoreOnly = document.createElement('button'); restoreOnly.type='button'; restoreOnly.textContent = '入力だけ復元'; restoreOnly.hidden=true;
  const clear = document.createElement('button'); clear.type='button'; clear.textContent = '保存情報を削除'; clear.hidden=true;
  buttons.append(restore,restoreOnly,clear);
  const note = document.createElement('p'); note.className='etc-credentials-note';
  note.textContent='初回のログイン成功後にKeychainへ保存します。次回のアプリ起動時はFace ID／Touch IDまたはパスコードで認証後、自動ログインします。';
  panel.append(label,buttons,note);
  // Prefer the visible v4.6 card. Legacy markup can contain a hidden card.
  const target = form.querySelector('.etc-login-shell .etc-login-form-card') ||
                 form.querySelector('.etc-login-form-card') || form;
  target.appendChild(panel);

  function message(action, more={}) {
    try { bridge.postMessage({action, ...more}); } catch (_) { /* Browser userscript mode: no native bridge */ }
  }
  form.addEventListener('submit', () => {
    if (checkbox.checked) message('candidate', {
      companyID: company.value.trim(), userID: user.value.trim(), password: pass.value
    });
  });
  restore.addEventListener('click', () => message('authenticateAndLogin'));
  restoreOnly.addEventListener('click', () => message('restore'));
  clear.addEventListener('click', () => message('delete'));
  window.__etcCredentialStatus = function (hasSaved, text) {
    restore.hidden = !hasSaved;
    restoreOnly.hidden = !hasSaved;
    clear.hidden = !hasSaved;
    if (text) note.textContent = text;
  };
  window.__etcCredentialApply = function (saved) {
    if (!saved || typeof saved !== 'object') return;
    for (const [field,value] of [[company,saved.companyID],[user,saved.userID],[pass,saved.password]]) {
      if (typeof value !== 'string') continue;
      field.value = value;
      field.dispatchEvent(new Event('input',{bubbles:true}));
      field.dispatchEvent(new Event('change',{bubbles:true}));
    }
    checkbox.checked = true;
    note.textContent = '保存された情報を入力しました。内容を確認して「ログイン」を押してください。';
  };
  // Called ONLY by the native WebView after successful device authentication.
  // Never auto-submit on the webpage's own load, without a native Face ID/
  // Touch ID/passcode check.  Native code only calls this on the trusted origin.
  window.__etcCredentialAutoSubmit = function (saved) {
    if (location.origin !== 'https://m.e-staffing.ne.jp' ||
        !location.pathname.startsWith('/s/') ||
        !document.querySelector('form[name="TMSLGN01ActionForm"]')) return false;
    const currentForm = document.querySelector('form[name="TMSLGN01ActionForm"]');
    if (currentForm !== form || form.dataset.etcAutomaticSubmitted === '1') return false;
    if (!saved || typeof saved.companyID !== 'string' ||
        typeof saved.userID !== 'string' || typeof saved.password !== 'string' ||
        !saved.userID || !saved.password) return false;
    const submitButton = form.querySelector('input[type="submit"][name="login"]');
    if (!submitButton || submitButton.disabled) return false;
    const actionURL = new URL(form.action, location.href);
    if (actionURL.origin !== location.origin ||
        !actionURL.pathname.startsWith('/s/TMSLGN01/')) return false;
    window.__etcCredentialApply(saved);
    form.dataset.etcAutomaticSubmitted = '1';
    note.textContent = '本人確認が完了しました。自動ログインしています…';
    // Preserve e-staffing's native POST and the named "login" submit control.
    submitButton.click();
    return true;
  };
  message('status');
})();
