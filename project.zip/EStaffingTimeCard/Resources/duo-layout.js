/* iPhone Duo responsive additions: do not assume fixed screen size or orientation. */
(() => {
  'use strict';
  if (location.origin !== 'https://m.e-staffing.ne.jp' || !location.pathname.startsWith('/s/')) return;
  const s = document.createElement('style');
  s.id = 'etc-duo-layout';
  s.textContent = `
    :root { --etc-content-max:690px; }
    html, body { max-width:100%; }
    body.etc-native-v4 { overflow-x:clip; }
    body.etc-native-v4 .etc-native-header,
    body.etc-native-v4 .etc-content,
    body.etc-native-v4 form.etc-enhanced-form,
    body.etc-native-v4 .etc-nav-inner { max-width:min(var(--etc-content-max), 100%) !important; }
    /* On iPhone Duo, left/right safe areas may be different. */
    body.etc-native-v4 .etc-content,
    body.etc-native-v4 form.etc-enhanced-form {
      padding-left:max(16px,env(safe-area-inset-left,0px)) !important;
      padding-right:max(16px,env(safe-area-inset-right,0px)) !important;
    }
    body.etc-native-v4 .etc-native-header {
      padding-left:max(20px,env(safe-area-inset-left,0px)) !important;
      padding-right:max(20px,env(safe-area-inset-right,0px)) !important;
    }
    @media (min-width:700px) {
      :root { --etc-content-max:960px; }
      body.etc-native-v4 .etc-content,
      body.etc-native-v4 form.etc-enhanced-form { padding-left:24px!important; padding-right:24px!important; }
      body.etc-native-v4 .etc-nav-inner { max-width:900px!important; }
    }
    @media (min-width:1050px) {
      :root { --etc-content-max:1120px; }
      body.etc-native-v4 .etc-nav-inner { max-width:1020px!important; }
    }
    @media (max-width:360px) {
      body.etc-native-v4 .etc-content,
      body.etc-native-v4 form.etc-enhanced-form { padding-left:12px!important; padding-right:12px!important; }
      body.etc-native-v4 .etc-form-card { min-width:0!important; max-width:100%!important; }
    }
    body.etc-native-v4 input, body.etc-native-v4 select { max-width:100%; }
  `;
  (document.head || document.documentElement).appendChild(s);
})();
