/*
 * v2.7 Break assistance for the official e-staffing daily attendance form.
 * Changes form field only, NEVER submits, saves, or sends a network request.
 * Values are proposals and must be verified against actual break time.
 */
(() => {
  'use strict';
  if (location.hostname !== 'm.e-staffing.ne.jp' || !location.pathname.startsWith('/s/')) return;
  const form = document.querySelector('form[name="TMSINP01ActionForm"]');
  if (!form || form.dataset.etcBreakAssistant === '1') return;
  const start = form.querySelector('input[name="startTime"]');
  const end = form.querySelector('input[name="endTime"]');
  const rest = form.querySelector('input[name="rstTime"]');
  if (!start || !end || !rest) return;
  form.dataset.etcBreakAssistant = '1';

  const parseHHMM = value => {
    const raw = String(value ?? '').trim();
    const match = raw.match(/^(\d{1,2}):(\d{2})$/) || raw.match(/^(\d{1,2})(\d{2})$/);
    if (!match) return null;
    const hours = Number(match[1]), minutes = Number(match[2]);
    if (hours > 23 || minutes > 59) return null;
    return 60 * hours + minutes;
  };
  const proposedBreak = (startValue, endValue) => {
    const a = parseHHMM(startValue), b = parseHHMM(endValue);
    if (a == null || b == null) return null;
    let span = b - a;
    if (span < 0) span += 1440; // Overnight shift
    if (span === 0 || span > 16 * 60) return null; // No ambiguous 24-hour input
    // A conservative span-based *proposal*, not a claim that break was taken.
    // Statutory tiers apply to working time excluding actual breaks.
    if (span > 8 * 60) return 60;
    if (span > 6 * 60) return 45;
    return 0;
  };

  // Use the site's numeric MINUTES format; never use HHMM for the break field.
  const setValue = (field, value) => {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    if (setter) setter.call(field, value);
    else field.value = value;
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
  };

  // Only blank or zero defaults are editable automatically. Anything the user
  // edits, and any existing nonzero employer/site value, is always protected.
  let autoWritten = null;
  let userEdited = false;
  let programmatic = false;
  const display = document.createElement('div');
  display.className = 'etc-break-assistant';
  display.setAttribute('role', 'status');
  const caption = document.createElement('span');
  caption.className = 'etc-break-assistant-caption';
  const recalc = document.createElement('button');
  recalc.type = 'button';
  recalc.className = 'etc-break-assistant-button';
  recalc.textContent = '再計算';
  display.append(caption, recalc);
  const note = document.createElement('p');
  note.className = 'etc-break-assistant-note';
  note.textContent = '勤務時間から休憩の目安を自動入力します。実際に取得した休憩に合わせて修正してください（自動申請はしません）。';

  const update = (force = false) => {
    const value = proposedBreak(start.value, end.value);
    if (value === null) {
      caption.textContent = '開始・終了時刻が揃うと休憩時間を計算します';
      if (!force && autoWritten !== null && !userEdited && !rest.readOnly && !rest.disabled) {
        programmatic = true;
        try { setValue(rest, ''); autoWritten = null; } finally { programmatic = false; }
      }
      return;
    }
    caption.textContent = `休憩目安 ${value}分（開始・終了の差を基準）`;
    if (rest.disabled || rest.readOnly) return;
    const current = String(rest.value ?? '').trim();
    const autoOwned = autoWritten !== null && current === String(autoWritten);
    const untouchedDefault = !userEdited && (current === '' || current === '0' || current === '00');
    if (!force && !(autoOwned || untouchedDefault)) {
      caption.textContent = `休憩目安 ${value}分（既存の${current || '手動'}分を維持）`;
      return;
    }
    if (!force && userEdited) return;
    programmatic = true;
    try {
      setValue(rest, String(value));
      autoWritten = value;
      userEdited = false;
      caption.textContent = `休憩目安 ${value}分を自動入力しました`;
    } finally { programmatic = false; }
  };

  rest.addEventListener('input', () => {
    if (!programmatic) {
      userEdited = true;
      autoWritten = null;
      caption.textContent = '手動で変更した休憩時間を優先します';
    }
  });
  const schedule = () => update();
  start.addEventListener('input', schedule);
  start.addEventListener('change', schedule);
  end.addEventListener('input', schedule);
  end.addEventListener('change', schedule);
  recalc.addEventListener('click', () => update(true));

  // Keep the official form and its submit controls intact. Insert only a hint.
  const breakCard = rest.closest('.etc-form-card');
  const target = breakCard || rest.closest('table')?.parentElement || rest.parentElement;
  if (target) {
    target.append(display, note);
    const style = document.createElement('style');
    style.textContent = `
      .etc-break-assistant{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-top:11px;padding:10px 12px;border-radius:12px;background:var(--e-blue-wash,rgba(0,122,255,.10));color:var(--e-ink,inherit);}
      .etc-break-assistant-caption{font-size:12px;font-weight:650;line-height:1.5;flex:1;min-width:130px;}
      .etc-break-assistant-button{min-height:36px!important;padding:6px 11px!important;border:0!important;border-radius:10px!important;background:var(--e-blue,#007aff)!important;color:#fff!important;font-size:12px!important;font-weight:700!important;}
      .etc-break-assistant-note{color:var(--e-muted,#6e6e73);font-size:11px;line-height:1.6;margin:7px 3px 0;}
    `;
    (document.head || document.documentElement).appendChild(style);
  }
  update();
})();
