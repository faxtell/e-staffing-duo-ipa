(function() {
  try {
    if (location.origin !== 'https://m.e-staffing.ne.jp' || !location.pathname.startsWith('/s/')) return;
    document.documentElement.setAttribute('data-etc-native-preparing','1');
    const s=document.createElement('style');
    s.id='etc-ios-native-prepaint';
    s.textContent = `
      html[data-etc-native-preparing="1"] { background: #f2f2f7 !important; }
      @media (prefers-color-scheme: dark) { html[data-etc-native-preparing="1"] { background: #000 !important; } }
      html[data-etc-native-preparing="1"] body {
        visibility: hidden !important;
        animation: etc-native-autoreveal 0s step-end 5s both;
      }
      @keyframes etc-native-autoreveal { 0% { visibility:hidden; } 100% { visibility:visible; } }
    `;
    (document.head || document.documentElement).appendChild(s);
  } catch (_) {}
})();