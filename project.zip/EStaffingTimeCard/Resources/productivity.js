/* v2.9 Duo productivity enhancements. Official forms are never submitted by this file. */
(() => {
  'use strict';
  if (location.hostname !== 'm.e-staffing.ne.jp' || !location.pathname.startsWith('/s/')) return;
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const post=(data)=>{ try { window.webkit?.messageHandlers?.etcProductivityBridge?.postMessage(data); } catch {} };
  const set=(name,value)=>{ const el=document.getElementById('etc-v29-'+name);if(el)el.textContent=String(value); };
  const parseTime = value => {
    const m=String(value||'').trim().match(/^(\d{1,2}):?(\d{2})$/);
    if(!m)return null;
    const h=Number(m[1]),mm=Number(m[2]);
    return h<24&&mm<60?{h,mm,n:h*60+mm}:null;
  };
  // Only works with complete official records; incomplete entries are skipped.
  const compute = payload => {
    if(!payload || !Array.isArray(payload.days))return null;
    const rows=payload.days.filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.date));
    let total=0,valid=0,pending=0;
    rows.forEach(x=>{
      const match=String(x.hours||'').match(/(\d{1,2}):?(\d{2})\s*[-－〜～~–]\s*(\d{1,2}):?(\d{2})/);
      if(!match)return;
      const start=parseTime(match[1]+match[2]),end=parseTime(match[3]+match[4]);
      if(!start||!end)return;
      let span=end.n-start.n;if(span<0)span+=1440;
      const rest=Number(x.rest);
      if(span>0&&span<=16*60&&Number.isFinite(rest)&&rest>=0&&rest<span){total+=span-rest;valid++;}
    });
    const weekdayEmpty=rows.filter(x=>{const d=new Date(x.date+'T12:00:00');return d.getDay()!==0&&d.getDay()!==6&&!x.work&&!x.leave;}).length;
    const worked=rows.filter(x=>x.work).length;
    const approved=rows.filter(x=>/承認済|承認完了/.test(x.status||'')).length;
    const explicitlyPending=rows.filter(x=>/申請中|承認待|申請待/.test(x.status||'')).length;
    const today=new Date();const key=[today.getFullYear(),String(today.getMonth()+1).padStart(2,'0'),String(today.getDate()).padStart(2,'0')].join('-');
    const record=rows.find(x=>x.date===key);
    const todayStatus=record?(record.leave?'有給休暇':record.work?(record.status||'入力あり'):(record.status||'記録なし')):'対象期間外・未確認';
    return {start:payload.start,end:payload.end,worked,empty:weekdayEmpty,valid,minutes:total,approved,pending:explicitlyPending,todayStatus};
  };
  window.__etcReceiveDashboard = summary => {
    if(!summary)return;
    set('period',`${summary.start}〜${summary.end} の公式記録`);
    set('worked',`${summary.worked}日`);
    set('empty',`${summary.empty}日`);
    set('total',summary.valid===summary.worked?`${Math.floor(summary.minutes/60)}時間${String(summary.minutes%60).padStart(2,'0')}分`:'—');
    set('today',summary.todayStatus||'未確認');
    set('status-note',`承認済${summary.approved}件・申請中／承認待ち${summary.pending}件（公式表示に明記された状態のみ）。勤務時間は入力済みの時刻・休憩からの概算。勤務形態や休日を踏まえ公式画面で確認してください。`);
  };
  const data=window.__etcOfficialRecords;
  if(data?.days?.length){
    const summary=compute(data);
    post({action:'calendar',start:data.start,end:data.end,days:data.days,summary});
    // Filter is visual only. No data rows, input controls or links are removed.
    const card=$('.etc-close-calendar-section');const toolbar=$('.etc-calendar-toolbar',card||document);
    if(toolbar && !$('#etc-v29-filter')){
      const button=document.createElement('button');button.type='button';button.id='etc-v29-filter';button.className='etc-v29-filter';button.textContent='記録なしの平日を探す';button.setAttribute('aria-pressed','false');
      let active=false;
      button.addEventListener('click',()=>{
        active=!active;button.setAttribute('aria-pressed',String(active));button.textContent=active?'絞り込みを解除':'記録なしの平日を探す';
        $$('.etc-calendar-day',card).forEach(cell=>{
          const d=cell.closest('.etc-calendar-month');
          const yearMonth=d?.querySelector('.etc-calendar-month-title')?.textContent?.match(/(\d+)年(\d+)月/);
          const day=Number(cell.querySelector('.etc-calendar-day-number')?.textContent);
          const weekday=yearMonth?new Date(Number(yearMonth[1]),Number(yearMonth[2])-1,day).getDay():0;
          const missing=!cell.classList.contains('is-work')&&!cell.classList.contains('is-leave')&&!cell.classList.contains('is-other')&&weekday!==0&&weekday!==6;
          cell.classList.toggle('etc-v29-dim',active&&!missing);
          cell.classList.toggle('etc-v29-highlight',active&&missing);
        });
      });toolbar.appendChild(button);
    }
    // Enhance the official statuses; unknown status is never styled as "approved".
    $$('.etc-date-calendar .etc-calendar-day').forEach(cell=>{
      const status=cell.querySelector('.etc-calendar-tag')?.textContent||'';
      if(/承認済|承認完了/.test(status))cell.classList.add('etc-v29-approved');
      else if(/差戻|却下/.test(status))cell.classList.add('etc-v29-returned');
      else if(/申請中|承認待/.test(status))cell.classList.add('etc-v29-pending');
    });
  }

  // Accessible iOS-native time control backed by the ORIGINAL HHMM input.
  // Only user interactions write attendance values, and neither tool submits.
  const form=$('form[name="TMSINP01ActionForm"]');
  if(form){
    const inputs=['startTime','endTime'].map(n=>$(`input[name="${n}"]`,form));
    inputs.forEach((field,index)=>{
      if(!field || field.dataset.etcTimePicker==='1')return;
      field.dataset.etcTimePicker='1';
      const label=index===0?'出勤':'退勤';
      const parent=field.closest('.etc-now-inline')||field.parentElement;
      if(!parent)return;
      const wrap=document.createElement('span');wrap.className='etc-v29-time-actions';
      const picker=document.createElement('input');picker.type='time';picker.className='etc-v29-time-picker';picker.setAttribute('aria-label',`${label}時刻を選択`);picker.step='60';
      const refresh=()=>{const t=parseTime(field.value);picker.value=t?`${String(t.h).padStart(2,'0')}:${String(t.mm).padStart(2,'0')}`:'';};
      refresh();
      const change=()=>{
        const t=parseTime(picker.value);if(!t)return;
        const hhmm=String(t.h).padStart(2,'0')+String(t.mm).padStart(2,'0');
        const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
        if(setter)setter.call(field,hhmm);else field.value=hhmm;
        field.dispatchEvent(new Event('input',{bubbles:true}));
        field.dispatchEvent(new Event('change',{bubbles:true}));
      };
      picker.addEventListener('change',change);
      field.addEventListener('change',refresh);field.addEventListener('input',refresh);
      wrap.appendChild(picker);if(parent.classList.contains('etc-now-inline'))parent.after(wrap);else field.after(wrap);
    });
    if(inputs.every(Boolean) && !$('#etc-v29-template')){
      const controls=document.createElement('div');controls.id='etc-v29-template';controls.className='etc-v29-template';
      const save=document.createElement('button');save.type='button';save.textContent='この時刻を次回用に記憶';
      const recall=document.createElement('button');recall.type='button';recall.textContent='前回の時刻を呼び出す';
      const note=document.createElement('span');note.setAttribute('role','status');note.textContent='時刻のみ端末に保存。勤怠の保存・申請はしません。';
      save.addEventListener('click',()=>{
        if(inputs.some(f=>!parseTime(f.value))){note.textContent='出勤・退勤時刻を入力してください';return;}
        try {localStorage.setItem('etc-v29-time-template',JSON.stringify(inputs.map(f=>f.value)));note.textContent='次回用の時刻を保存しました';}catch{note.textContent='端末に保存できませんでした';}
      });
      recall.addEventListener('click',()=>{
        let v=null;try{v=JSON.parse(localStorage.getItem('etc-v29-time-template'));}catch{}
        if(!Array.isArray(v)||v.length!==2||v.some(t=>!parseTime(t))){note.textContent='保存した時刻がありません';return;}
        inputs.forEach((f,i)=>{
          if(f.disabled||f.readOnly)return;
          const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
          if(setter)setter.call(f,v[i]);else f.value=v[i];
          f.dispatchEvent(new Event('input',{bubbles:true}));f.dispatchEvent(new Event('change',{bubbles:true}));
        });note.textContent='時刻を読み込みました。内容を確認してください。';
      });
      controls.append(recall,save,note);
      const card=inputs[0]?.closest('.etc-card')||inputs[0]?.closest('table');
      (card||form).appendChild(controls);
    }
  }

  // User-opt-in local reminders, scheduled by UNUserNotificationCenter in native code.
  // They NEVER claim to have checked the site's latest saved/submitted state.
  const sheet=$('#etc-native-modal .etc-sheet');
  if(sheet && !$('#etc-v29-reminder-panel')){
    const panel=document.createElement('section');panel.id='etc-v29-reminder-panel';panel.className='etc-v29-reminders';
    const h=document.createElement('h3');h.textContent='通知・リマインダー';
    const desc=document.createElement('p');desc.textContent='曜日や締め日に確認を促す端末内通知です。e-staffingの未入力／未申請を自動判定する通知ではありません。';
    const make=(kind,title,defaultHour,defaultDay)=>{
      const row=document.createElement('label');row.className='etc-v29-reminder-row';
      const cb=document.createElement('input');cb.type='checkbox';cb.setAttribute('aria-label',title);
      const span=document.createElement('span');span.textContent=title;
      const tm=document.createElement('input');tm.type='time';tm.value=defaultHour;tm.setAttribute('aria-label',title+'の通知時刻');
      const day=document.createElement('select');day.setAttribute('aria-label','締め日');
      if(defaultDay){for(let x=1;x<=28;x++){const option=document.createElement('option');option.value=String(x);option.textContent=`${x}日`;day.appendChild(option);}day.value=String(defaultDay);}
      else day.hidden=true;
      const state=document.createElement('small');state.setAttribute('role','status');
      const send=()=>{
        const [hour,minute]=tm.value.split(':').map(Number);
        if(!Number.isInteger(hour)||!Number.isInteger(minute))return;
        post({action:'reminder',kind,enabled:cb.checked,hour,minute,day:Number(day.value)||15});
      };
      cb.addEventListener('change',send);tm.addEventListener('change',()=>{if(cb.checked)send();});day.addEventListener('change',()=>{if(cb.checked)send();});
      row.append(cb,span,tm);if(defaultDay)row.append(day);row.append(state);panel.appendChild(row);
      return {cb,tm,day,state};
    };
    panel.append(h,desc);
    const weekday=make('weekday','平日の入力確認', '18:30',null);
    const close=make('close','毎月の締め確認','17:00',15);
    sheet.appendChild(panel);
    window.__etcReminderStatus = payload => {
      if(!payload)return;
      for(const [key,widget] of [['weekday',weekday],['close',close]]){
        const v=payload[key];if(!v)continue;
        widget.cb.checked=!!v.enabled;
        if(Number.isInteger(v.hour)&&Number.isInteger(v.minute))widget.tm.value=`${String(v.hour).padStart(2,'0')}:${String(v.minute).padStart(2,'0')}`;
        if(Number.isInteger(v.day)&&key==='close')widget.day.value=String(v.day);
        widget.state.textContent=v.message||'';
      }
    };
    post({action:'reminderStatus'});
  }
  const style=document.createElement('style');style.id='etc-v29-styles';style.textContent=`
    .etc-v29-summary {margin:12px 0 20px;padding:17px;border:1px solid var(--e-line);background:var(--e-card);border-radius:20px;}
    .etc-v29-summary-head{display:flex;flex-direction:column;gap:3px;margin-bottom:14px;}
    .etc-v29-summary-head strong{font-size:17px;}.etc-v29-summary-head small{color:var(--e-muted);font-size:11px;}
    .etc-v29-summary-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;}
    .etc-v29-summary-grid>div{min-width:0;border-radius:12px;background:var(--e-soft);padding:14px 10px;}
    .etc-v29-summary-grid small{display:block;color:var(--e-muted);font-size:11px;margin-bottom:7px;}
    .etc-v29-summary-grid strong{font-size:19px;line-height:1.3;overflow-wrap:anywhere;}
    .etc-v29-summary-note{color:var(--e-muted);font-size:11px;line-height:1.6;margin:12px 0 0;}
    .etc-v29-time-actions{display:inline-flex;align-items:center;vertical-align:middle;margin:5px 0 5px 7px;}
    body.etc-native-v4 input.etc-v29-time-picker{min-width:125px;width:138px;min-height:42px;font-size:15px!important;}
    .etc-v29-template{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:12px;padding:11px;border-radius:12px;background:var(--e-soft);}
    .etc-v29-template button,.etc-v29-filter{font-size:12px!important;background:var(--e-blue-wash)!important;border:0!important;color:var(--e-blue)!important;border-radius:10px!important;padding:9px!important;min-height:36px!important;}
    .etc-v29-template span{width:100%;color:var(--e-muted);font-size:11px;}
    .etc-v29-filter[aria-pressed=true]{background:var(--e-blue)!important;color:white!important;}
    .etc-v29-dim{opacity:.28!important;}.etc-v29-highlight{box-shadow:inset 0 0 0 2px var(--e-blue)!important;}
    .etc-v29-approved .etc-calendar-tag{color:var(--e-green)!important;}
    .etc-v29-returned .etc-calendar-tag{color:var(--e-red)!important;}
    .etc-v29-pending .etc-calendar-tag{color:var(--e-blue)!important;}
    .etc-v29-reminders{padding:12px 15px 18px;border-top:1px solid var(--e-line);}
    .etc-v29-reminders h3{font-size:16px;margin:8px 0;}.etc-v29-reminders p{font-size:12px;color:var(--e-muted);line-height:1.5;}
    .etc-v29-reminder-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:13px 0;padding:10px;border-radius:10px;background:var(--e-soft);font-size:12px;}
    .etc-v29-reminder-row>span{flex:1;min-width:90px;}.etc-v29-reminder-row input[type=time]{max-width:110px;min-height:36px;font-size:12px!important;}
    .etc-v29-reminder-row select{width:85px;min-height:36px;font-size:12px!important;}.etc-v29-reminder-row small{display:block;width:100%;color:var(--e-muted);}
    @media(min-width:720px){.etc-v29-summary-grid{grid-template-columns:repeat(4,minmax(0,1fr));}}
  `;(document.head||document.documentElement).appendChild(style);
})();
