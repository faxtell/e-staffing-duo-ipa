/* v2.9 Duo productivity enhancements. Official forms are never submitted by this file. */
(() => {
  'use strict';
  if (location.hostname !== 'm.e-staffing.ne.jp' || !location.pathname.startsWith('/s/')) return;
  try { localStorage.removeItem('etc-v29-time-template'); } catch {}
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const post=(data)=>{ try { window.webkit?.messageHandlers?.etcProductivityBridge?.postMessage(data); } catch {} };
  const set=(name,value)=>{ const el=document.getElementById('etc-v29-'+name);if(el)el.textContent=String(value); };
  const parseTime = value => {
    const m=String(value||'').trim().match(/^(\d{1,2}):?(\d{2})$/);
    if(!m)return null;
    const h=Number(m[1]),mm=Number(m[2]);
    return h<24&&mm<60?{h,mm,n:h*60+mm}:null;
  };
  // Only works with complete official records; incomplete entries are skipped.
  const keyForToday=()=>{const n=new Date();return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-${String(n.getDate()).padStart(2,'0')}`;};
  const compute = payload => {
    if(!payload || !Array.isArray(payload.days))return null;
    const rows=payload.days.filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.date));
    let total=0, overtime=0, valid=0;
    // The closing page contains ONE official submission period (often half a
    // month). Never label it a full calendar month or synthesize missing days.
    const uniqueRows=Array.from(new Map(rows.map(x=>[x.date,x])).values());
    uniqueRows.forEach(x=>{
      const match=String(x.hours||'').match(/(\d{1,2}):?(\d{2})\s*[-－〜～~–]\s*(\d{1,2}):?(\d{2})/);
      if(!match)return;
      const start=parseTime(match[1]+match[2]),end=parseTime(match[3]+match[4]);
      if(!start||!end)return;
      let span=end.n-start.n;if(span<0)span+=1440;
      const rawRest=String(x.rest??'').trim();
      // Official pages can express break length as minutes or H:MM.
      const restMatch=rawRest.match(/^(\d{1,2}):(\d{2})$/);
      const rest=restMatch?Number(restMatch[1])*60+Number(restMatch[2]):
        (rawRest!==''?Number(rawRest):NaN);
      if(span>0&&span<=16*60&&Number.isFinite(rest)&&rest>=0&&rest<span){
        const actual=span-rest;
        total+=actual;
        overtime+=Math.max(0,actual-8*60); // strictly OVER eight actual hours, per day
        valid++;
      }
    });
    const weekdayEmpty=uniqueRows.filter(x=>{const d=new Date(x.date+'T12:00:00');return d.getDay()!==0&&d.getDay()!==6&&!window.__etcJapanHolidayName?.(x.date)&&!x.work&&!x.leave&&x.date<=keyForToday();}).length;
    const worked=uniqueRows.filter(x=>x.work).length;
    const approved=uniqueRows.filter(x=>/承認済|承認完了/.test(x.status||'')).length;
    const explicitlyPending=uniqueRows.filter(x=>/申請中|承認待|申請待/.test(x.status||'')).length;
    const explicitUnsent=uniqueRows.filter(x=>/未申請|申請前|未提出/.test(x.status||'')).length;
    const submissionStatesPresent=uniqueRows.some(x=>/未申請|申請前|未提出|申請中|申請待|承認待|承認済|承認完了|差戻|却下/.test(x.status||''));
    const today=new Date();const key=[today.getFullYear(),String(today.getMonth()+1).padStart(2,'0'),String(today.getDate()).padStart(2,'0')].join('-');
    const record=uniqueRows.find(x=>x.date===key);
    const todayStatus=record?(record.leave?'有給休暇':record.work?(record.status||'入力あり'):(record.status||'記録なし')):'対象期間外・未確認';
    return {start:payload.start,end:payload.end,worked,empty:weekdayEmpty,valid,minutes:total,overtimeMinutes:overtime,approved,pending:explicitlyPending,unsent:submissionStatesPresent?explicitUnsent:null,todayStatus};
  };
  // Automatic dashboard refresh uses official navigation in the SAME main
  // WKWebView; no popup, iframe, fetch, URLSession, browser-back or second tab.
  // The native coordinator calls this once per app launch after confirming
  // that the authenticated staff home form has loaded.
  window.__etcBeginDashboardRefresh = () => {
    if (!document.querySelector('form[name="TMSMNU01ActionForm"]')) return false;
    const link = document.querySelector('#etc-native-nav .etc-nav-inner a:nth-of-type(3)');
    if (!link) return false;
    let url;
    try { url = new URL(link.href); } catch { return false; }
    if (url.protocol !== 'https:' || url.host !== 'm.e-staffing.ne.jp' ||
        !/^\/s\/TMSMNU01\/close\/?$/.test(url.pathname)) return false;
    if (window.__etcDashboardAutoRefreshPending) return false;
    window.__etcDashboardAutoRefreshPending = true;
    set('period','公式画面から最新の勤務記録を取得しています…');
    // Click the existing official link exactly as an ordinary user would.
    link.click();
    return true;
  };
  // Navigates ONLY via the official prev/next anchor already in the close form.
  // This avoids replaying date-entry URLs and never submits applications.
  window.__etcVisitSiblingPeriod = direction => {
    if (!['prev','next'].includes(direction) || !document.querySelector('form[name="TMSINP02ActionForm"]')) return false;
    const form=document.querySelector('form[name="TMSINP02ActionForm"]');
    const link=Array.from(form.querySelectorAll('a[href]')).find(a=>{
      try {
        const u=new URL(a.href,location.href);
        return u.protocol==='https:' && u.host==='m.e-staffing.ne.jp' &&
          new RegExp('^/s/TMSINP02/'+direction+'/?$').test(u.pathname);
      } catch { return false; }
    });
    if(!link)return false;
    link.click();
    return true;
  };
  // v2.9.6: calendar taps navigate via the ONE existing official WKWebView.
  // For a date in the CURRENT closing period, click the actual original row
  // link from the live DOM (never cached links/constructed URLs/Struts replay).
  // Other dates fall back to the official Daily tab, where the user chooses a
  // date using the site's own controls. Do not submit any application.
  window.__etcOpenCalendarDate = date => {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date||'')))return false;
    if(window.__etcNavigationPending)return false;
    const onClose=!!document.querySelector('form[name="TMSINP02ActionForm"]');
    const official=window.__etcOfficialRecords;
    if(onClose && official && date>=official.start && date<=official.end){
      const day=official.days?.find(x=>x.date===date);
      if(day?.href){
        const anchors=Array.from(document.querySelectorAll('form[name="TMSINP02ActionForm"] .etc-date-list tbody tr td:first-child a[href]'));
        const link=anchors.find(a=>{
          try{const u=new URL(a.href,location.href);
            return a.href===day.href && u.protocol==='https:' && u.host==='m.e-staffing.ne.jp' && u.pathname.startsWith('/s/');
          }catch{return false;}
        });
        if(link){ window.__etcNavigationPending=true; link.click(); return true; }
      }
    }
    // Same-page Daily has no supported date selector endpoint: never silently
    // change the official selected date, reload, or move its history.
    if(document.querySelector('form[name="TMSINP01ActionForm"]'))return false;
    return window.__etcNativeNavigate?.('daily')===true;
  };
  // The closing-page calendar is a second VIEW of the same official records.
  // Its date cells are not new links; they forward user-initiated taps to the
  // same current-page official navigation routine above.
  if(document.querySelector('form[name="TMSINP02ActionForm"]')){
    document.querySelectorAll('.etc-date-calendar .etc-calendar-day[data-date]').forEach(cell=>{
      const date=cell.dataset.date;
      if(!/^\d{4}-\d{2}-\d{2}$/.test(date||''))return;
      cell.setAttribute('role','button');cell.tabIndex=0;
      cell.setAttribute('aria-label',`日々勤怠を開く：${date}`);
      cell.addEventListener('click',()=>window.__etcOpenCalendarDate(date));
      cell.addEventListener('keydown',event=>{
        if(event.key==='Enter'||event.key===' '){event.preventDefault();window.__etcOpenCalendarDate(date);}
      });
    });
    const hint=document.querySelector('.etc-calendar-reference-hint');
    if(hint)hint.textContent='日付を押すと公式の日々勤怠を開きます。別の締め期間の日付は公式の日付選択で確認してください。';
  }

  window.__etcReceiveDashboard = summary => {
    if(!summary)return;
    const formatDate=value=>String(value||'').replace(/^(\d{4})-(\d{2})-(\d{2})$/,(_,y,m,d)=>`${Number(y)}年${Number(m)}月${Number(d)}日`);
    const isMonth=summary.coverage==='month';
    set('period',isMonth?`対象：${formatDate(summary.start)}〜${formatDate(summary.end)}（1か月・2期間合算）`:
      `対象：${formatDate(summary.start)}〜${formatDate(summary.end)}（取得済みの1期間のみ）`);
    set('worked',`${summary.worked}日`);
    set('empty',`${summary.empty}日`);
    set('unsent',summary.unsent===null || summary.unsent===undefined?'—':`${summary.unsent}件`);
    const allParsed=summary.valid===summary.worked && Number.isSafeInteger(summary.minutes) && Number.isSafeInteger(summary.overtimeMinutes);
    const formatMinutes=n=>`${Math.floor(n/60)}時間${String(n%60).padStart(2,'0')}分`;
    set('total',allParsed?formatMinutes(summary.minutes):'—');
    set('overtime',allParsed?formatMinutes(summary.overtimeMinutes):'—');
    set('today',summary.todayStatus||'未確認');

  };

  // v2.9.6: hourly wage preference is stored only in native UserDefaults.
  // Nothing financial is sent to the official server or saved to its origin.
  let salaryPreferences={enabled:false,rate:0,premium:true};
  let lastSummary=null;
  let salaryElements=null;
  const yen=n=>new Intl.NumberFormat('ja-JP',{style:'currency',currency:'JPY',maximumFractionDigits:0}).format(Math.round(n));
  const salaryCard=document.querySelector('#etc-v29-summary .etc-v29-summary-grid');
  if(salaryCard){
    const card=document.createElement('div');card.id='etc-v296-wage-card';card.hidden=true;
    card.innerHTML='<small id="etc-v296-wage-label">給与目安</small><strong id="etc-v296-wage-value">—</strong>';
    salaryCard.appendChild(card);
  }
  const renderWage=()=>{
    const card=document.getElementById('etc-v296-wage-card');
    if(!card)return;
    card.hidden=!(salaryPreferences.enabled && salaryPreferences.rate>0);
    if(card.hidden)return;
    const summary=lastSummary;
    const label=document.getElementById('etc-v296-wage-label');
    if(label)label.textContent=summary?.coverage==='month'?'給与目安':'給与目安（取得分）';
    const out=document.getElementById('etc-v296-wage-value');
    if(!out)return;
    if(!summary || summary.worked!==summary.valid || !Number.isSafeInteger(summary.minutes) || !Number.isSafeInteger(summary.overtimeMinutes)){
      out.textContent='—';return;
    }
    // gross estimate: regular work × rate + daily >8h premium (optional 25%).
    // No weekly over-40h, late-night/holiday premiums, expenses, deductions.
    const amount=summary.minutes/60*salaryPreferences.rate+
      (salaryPreferences.premium?summary.overtimeMinutes/60*salaryPreferences.rate*.25:0);
    out.textContent=Number.isFinite(amount)?yen(amount):'—';
  };
  const salarySheet=document.querySelector('#etc-native-modal .etc-sheet');
  if(salarySheet && !document.getElementById('etc-v296-salary-panel')){
    const panel=document.createElement('section');panel.id='etc-v296-salary-panel';
    panel.innerHTML=`<h3>給与計算</h3>
      <label class="etc-v296-salary-row"><span>給与目安を表示</span><input id="etc-v296-salary-enabled" type="checkbox" aria-label="給与計算をオンオフ"></label>
      <label class="etc-v296-salary-row"><span>時給（円）</span><input id="etc-v296-hourly" type="number" min="0" max="100000" step="1" inputmode="numeric" placeholder="例：2000"></label>
      <label class="etc-v296-salary-row"><span>8時間超の25%割増</span><input id="etc-v296-premium" type="checkbox" checked></label>
      <small>税金・交通費・週40時間超・深夜・休日割増は含まない概算です。</small><p id="etc-v296-salary-message" role="status"></p>`;
    // Visually group with other settings, but do not interfere with the site's form.
    salarySheet.insertBefore(panel,document.getElementById('etc-v29-reminder-panel')||null);
    const enabled=panel.querySelector('#etc-v296-salary-enabled');
    const rate=panel.querySelector('#etc-v296-hourly');
    const premium=panel.querySelector('#etc-v296-premium');
    const status=panel.querySelector('#etc-v296-salary-message');
    const save=()=>{
      const n=Number(rate.value);
      if(!Number.isInteger(n)||n<0||n>100000){status.textContent='時給は0〜100000円の整数で入力してください。';return;}
      if(enabled.checked && n===0){status.textContent='時給を入力してからオンにしてください。';return;}
      post({action:'salarySave',enabled:enabled.checked,rate:n,premium:premium.checked});
    };
    enabled.addEventListener('change',save);
    premium.addEventListener('change',save);
    rate.addEventListener('change',save);
    salaryElements={enabled,rate,premium,status};
  }
  window.__etcSalaryStatus=payload=>{
    if(!payload || typeof payload.enabled!=='boolean' || !Number.isInteger(payload.rate) || typeof payload.premium!=='boolean')return;
    salaryPreferences={enabled:payload.enabled,rate:payload.rate,premium:payload.premium};
    if(salaryElements){
      salaryElements.enabled.checked=payload.enabled;
      salaryElements.rate.value=String(payload.rate||'');
      salaryElements.premium.checked=payload.premium;
      salaryElements.status.textContent=payload.message||'';
    }
    renderWage();
  };
  // Existing function still owns the other dashboard KPIs.
  const receiveDashboard=window.__etcReceiveDashboard;
  window.__etcReceiveDashboard=summary=>{
    lastSummary=summary;
    receiveDashboard?.(summary);
    renderWage();
  };
  post({action:'salaryStatus'});

  // Only sanitized read-only calendar facts cross the native bridge. No URLs,
  // form fields, CSRF tokens or cookies; always one official WKWebView.
  const snapshotCalendar = data => {
    const start=String(data?.start||''),end=String(data?.end||'');
    if(!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end) || start.slice(0,7)!==end.slice(0,7))return null;
    const month=start.slice(0,7);
    const [year,mm]=month.split('-').map(Number);
    const last=new Date(year,mm,0).getDate();
    const daymap=new Map((data.days||[]).filter(x=>x.date?.startsWith(month)).map(x=>[x.date,x]));
    const rows=[];
    for(let day=1;day<=last;day++){
      const date=`${month}-${String(day).padStart(2,'0')}`;
      const v=daymap.get(date);
      const known=date>=start&&date<=end&&!!v;
      rows.push({date,known,work:known&&!!v.work,leave:known&&!!v.leave,
        hours:known?String(v.hours||'').slice(0,40):'',rest:known?String(v.rest||'').slice(0,20):'',
        place:known?String(v.place||'').slice(0,35):'',
        status:known?String(v.status||'').slice(0,45):'',
        holiday:String(window.__etcJapanHolidayName?.(date)||'').slice(0,40)});
    }
    return {month,start,end,rows};
  };
  // Received from ONE WKWebView's prior official closing pages. Only updates
  // cells in the read-only calendar, NEVER date links or form actions.
  window.__etcReceiveMonthlyCalendar = rows => {
    if(!Array.isArray(rows))return false;
    const calendar=document.querySelector('.etc-close-calendar-section .etc-date-calendar');
    if(!calendar)return false;
    const byDate=new Map(rows.filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.date||'')).map(x=>[x.date,x]));
    calendar.querySelectorAll('.etc-calendar-day[data-date]').forEach(cell=>{
      const x=byDate.get(cell.dataset.date);if(!x)return;
      const holiday=x.holiday||window.__etcJapanHolidayName?.(x.date)||'';
      cell.classList.remove('is-work','is-leave','etc-v295-unfetched','etc-v295-holiday','etc-v29-approved','etc-v29-pending','etc-v29-returned');
      if(holiday) {cell.classList.add('etc-v295-holiday');cell.title=holiday;}
      else cell.removeAttribute('title');
      if(!x.known)cell.classList.add('etc-v295-unfetched');
      if(x.known && x.work)cell.classList.add('is-work');
      else if(x.known && x.leave)cell.classList.add('is-leave');
      const time=cell.querySelector('.etc-calendar-time');
      if(time){
        const hh=String(x.hours||'').replace(/^(\d{2})(\d{2})\s*[-－〜～]\s*(\d{2})(\d{2})$/,'$1:$2–$3:$4');
        time.textContent=x.known?(x.work?hh:x.leave?'年次有給休暇':holiday||'入力なし'):'未取得';
      }
      let line=cell.querySelector('.etc-calendar-subline');
      if(!x.known||!x.work){line?.remove();line=null;}
      else{
        if(!line){line=document.createElement('div');line.className='etc-calendar-subline';cell.querySelector('.etc-calendar-time')?.after(line);}
        if(line)line.textContent=(x.place==='オ'?'オフィス':x.place==='自'?'自宅':x.place||'勤務')+(x.rest?' · 休'+x.rest+'分':'');
      }
      let badge=cell.querySelector('.etc-calendar-tag');
      if(badge){badge.className='etc-calendar-tag';
        badge.textContent=!x.known?'未取得':(x.work?x.status||'入力あり':x.leave?x.status||'年休':holiday?'祝日・記録なし':(new Date(x.date+'T12:00:00').getDay()%6===0?'休日・記録なし':'記録なし'));
        badge.classList.add(x.work?'is-work':x.leave?'is-leave':'is-empty');
      }
      if(/承認済|承認完了/.test(x.status||''))cell.classList.add('etc-v29-approved');
      else if(/差戻|却下/.test(x.status||''))cell.classList.add('etc-v29-returned');
      else if(/申請中|承認待/.test(x.status||''))cell.classList.add('etc-v29-pending');
      cell.setAttribute('aria-label',`${x.date}、${x.known?(x.work?x.hours:x.leave?'年次有給休暇':holiday||'記録なし'):'未取得'}。日々勤怠は公式メニューで操作`);
    });
    return true;
  };

  const data=window.__etcOfficialRecords;
  if(data?.days?.length){
    const summary=compute(data);
    // Native receives aggregate-only values, not date-specific links, tokens or raw rows.
    if(summary){ post({action:'calendarSnapshot',snapshot:snapshotCalendar(data)});post({action:'dashboard',summary}); }
    // Filter is visual only. No data rows, input controls or links are removed.
    const card=$('.etc-close-calendar-section');const toolbar=$('.etc-calendar-toolbar',card||document);
    if(toolbar && !$('#etc-v29-filter')){
      const button=document.createElement('button');button.type='button';button.id='etc-v29-filter';button.className='etc-v29-filter';button.textContent='記録なしの平日を探す';button.setAttribute('aria-pressed','false');
      let active=false;
      button.addEventListener('click',()=>{
        active=!active;button.setAttribute('aria-pressed',String(active));button.textContent=active?'絞り込みを解除':'記録なしの平日を探す';
        $$('.etc-calendar-day',card).forEach(cell=>{
          const d=cell.closest('.etc-calendar-month');
          const yearMonth=d?.querySelector('.etc-calendar-month-title')?.textContent?.match(/(\d+)年(\d+)月/);
          const day=Number(cell.querySelector('.etc-calendar-day-number')?.textContent);
          const weekday=yearMonth?new Date(Number(yearMonth[1]),Number(yearMonth[2])-1,day).getDay():0;
          const key=yearMonth?`${yearMonth[1]}-${String(yearMonth[2]).padStart(2,'0')}-${String(day).padStart(2,'0')}`:'';
          const missing=!cell.classList.contains('is-work')&&!cell.classList.contains('is-leave')&&!cell.classList.contains('is-other')&&!cell.classList.contains('etc-v295-unfetched')&&weekday!==0&&weekday!==6&&!window.__etcJapanHolidayName?.(key)&&key<=keyForToday();
          cell.classList.toggle('etc-v29-dim',active&&!missing);
          cell.classList.toggle('etc-v29-highlight',active&&missing);
        });
      });toolbar.appendChild(button);
    }
    // Enhance the official statuses; unknown status is never styled as "approved".
    $$('.etc-date-calendar .etc-calendar-day').forEach(cell=>{
      const status=cell.querySelector('.etc-calendar-tag')?.textContent||'';
      if(/承認済|承認完了/.test(status))cell.classList.add('etc-v29-approved');
      else if(/差戻|却下/.test(status))cell.classList.add('etc-v29-returned');
      else if(/申請中|承認待/.test(status))cell.classList.add('etc-v29-pending');
    });
  }

  if (document.querySelector('form[name="TMSINP02ActionForm"]') && !data?.days?.length) {
    post({action:'dashboardUnavailable'});
  }

  // Accessible iOS-native time control backed by the ORIGINAL HHMM input.
  // Only user interactions write attendance values, and neither tool submits.
  const form=$('form[name="TMSINP01ActionForm"]');
  if(form){
    const inputs=['startTime','endTime'].map(n=>$(`input[name="${n}"]`,form));
    inputs.forEach((field,index)=>{
      if(!field || field.dataset.etcTimePicker==='1')return;
      field.dataset.etcTimePicker='1';
      const label=index===0?'出勤':'退勤';
      const parent=field.closest('.etc-now-inline')||field.parentElement;
      if(!parent)return;
      const wrap=document.createElement('span');wrap.className='etc-v29-time-actions';
      const picker=document.createElement('input');picker.type='time';picker.className='etc-v29-time-picker';picker.setAttribute('aria-label',`${label}時刻を選択`);picker.step='60';
      const refresh=()=>{const t=parseTime(field.value);picker.value=t?`${String(t.h).padStart(2,'0')}:${String(t.mm).padStart(2,'0')}`:'';};
      refresh();
      const change=()=>{
        const t=parseTime(picker.value);if(!t)return;
        const hhmm=String(t.h).padStart(2,'0')+String(t.mm).padStart(2,'0');
        const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
        if(setter)setter.call(field,hhmm);else field.value=hhmm;
        field.dispatchEvent(new Event('input',{bubbles:true}));
        field.dispatchEvent(new Event('change',{bubbles:true}));
      };
      picker.addEventListener('change',change);
      field.addEventListener('change',refresh);field.addEventListener('input',refresh);
      wrap.appendChild(picker);if(parent.classList.contains('etc-now-inline'))parent.after(wrap);else field.after(wrap);
    });
    // v2.9.1: Preferred/previous worktime templates were removed at user
    // request. Delete the old preference; do not touch official form inputs.
    try { localStorage.removeItem('etc-v29-time-template'); } catch {}

  }

  // User-opt-in local reminders, scheduled by UNUserNotificationCenter in native code.
  // They NEVER claim to have checked the site's latest saved/submitted state.
  const sheet=$('#etc-native-modal .etc-sheet');
  if(sheet && !$('#etc-v29-reminder-panel')){
    const panel=document.createElement('section');panel.id='etc-v29-reminder-panel';panel.className='etc-v29-reminders';
    const h=document.createElement('h3');h.textContent='通知・リマインダー';
    const desc=document.createElement('p');desc.textContent='曜日や締め日に確認を促す端末内通知です。e-staffingの未入力／未申請を自動判定する通知ではありません。';
    const make=(kind,title,defaultHour,defaultDay)=>{
      const row=document.createElement('label');row.className='etc-v29-reminder-row';
      const cb=document.createElement('input');cb.type='checkbox';cb.setAttribute('aria-label',title);
      const span=document.createElement('span');span.textContent=title;
      const tm=document.createElement('input');tm.type='time';tm.value=defaultHour;tm.setAttribute('aria-label',title+'の通知時刻');
      const day=document.createElement('select');day.setAttribute('aria-label','締め日');
      if(defaultDay){for(let x=1;x<=28;x++){const option=document.createElement('option');option.value=String(x);option.textContent=`${x}日`;day.appendChild(option);}day.value=String(defaultDay);}
      else day.hidden=true;
      const state=document.createElement('small');state.setAttribute('role','status');
      const send=()=>{
        const [hour,minute]=tm.value.split(':').map(Number);
        if(!Number.isInteger(hour)||!Number.isInteger(minute))return;
        post({action:'reminder',kind,enabled:cb.checked,hour,minute,day:Number(day.value)||15});
      };
      cb.addEventListener('change',send);tm.addEventListener('change',()=>{if(cb.checked)send();});day.addEventListener('change',()=>{if(cb.checked)send();});
      row.append(cb,span,tm);if(defaultDay)row.append(day);row.append(state);panel.appendChild(row);
      return {cb,tm,day,state};
    };
    panel.append(h,desc);
    const weekday=make('weekday','平日の入力確認', '18:30',null);
    const close=make('close','毎月の締め確認','17:00',15);
    sheet.appendChild(panel);
    window.__etcReminderStatus = payload => {
      if(!payload)return;
      for(const [key,widget] of [['weekday',weekday],['close',close]]){
        const v=payload[key];if(!v)continue;
        widget.cb.checked=!!v.enabled;
        if(Number.isInteger(v.hour)&&Number.isInteger(v.minute))widget.tm.value=`${String(v.hour).padStart(2,'0')}:${String(v.minute).padStart(2,'0')}`;
        if(Number.isInteger(v.day)&&key==='close')widget.day.value=String(v.day);
        widget.state.textContent=v.message||'';
      }
    };
    post({action:'reminderStatus'});
  }
  const style=document.createElement('style');style.id='etc-v29-styles';style.textContent=`
    .etc-v29-summary {margin:12px 0 20px;padding:17px;border:1px solid var(--e-line);background:var(--e-card);border-radius:20px;}
    .etc-v29-summary-head{display:flex;flex-direction:column;gap:3px;margin-bottom:14px;}
    .etc-v29-summary-head strong{font-size:17px;}.etc-v29-summary-head small{color:var(--e-muted);font-size:11px;}
    body.etc-native-v4 .etc-person-name{font-size:clamp(27px,5.5vw,39px)!important;}
    body.etc-native-v4 .etc-org-name{font-size:19px!important;}
    .etc-v29-summary-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;}
    #etc-v296-wage-card[hidden]{display:none!important;}
    .etc-v296-salary-row{display:flex;gap:12px;align-items:center;justify-content:space-between;padding:12px 10px;border-radius:11px;background:var(--e-soft);margin:8px 0;font-size:14px;}
    .etc-v296-salary-row span{flex:1;}
    .etc-v296-salary-row input[type=checkbox]{min-width:24px;min-height:24px;}
    body.etc-native-v4 #etc-v296-hourly{width:138px;min-width:0;min-height:41px;font-size:16px!important;}
    #etc-v296-salary-panel{border-top:1px solid var(--e-line);padding:12px 15px 18px;}
    #etc-v296-salary-panel h3{font-size:16px;margin:8px 0;}
    #etc-v296-salary-panel small{font-size:11px;color:var(--e-muted);line-height:1.5;display:block;}
    #etc-v296-salary-message{font-size:12px;color:var(--e-blue);min-height:14px;margin:5px 0;}
    .etc-date-calendar .etc-calendar-day[role=button]{cursor:pointer;}
    .etc-date-calendar .etc-calendar-day[role=button]:focus-visible{outline:2px solid var(--e-blue);outline-offset:2px;}
    .etc-v29-summary-grid>div{min-width:0;border-radius:12px;background:var(--e-soft);padding:14px 10px;}
    .etc-v29-summary-grid small{display:block;color:var(--e-muted);font-size:11px;margin-bottom:7px;}
    .etc-v29-summary-grid strong{font-size:19px;line-height:1.3;overflow-wrap:anywhere;}
    .etc-v295-unfetched{opacity:.46!important;}
    .etc-v295-holiday:not(.is-work):not(.is-leave){background:rgba(244,98,114,.11)!important;}
    .etc-v295-holiday .etc-calendar-day-number{color:#fa7985;}
    .etc-v29-time-actions{display:inline-flex;align-items:center;vertical-align:middle;margin:5px 0 5px 7px;}
    body.etc-native-v4 input.etc-v29-time-picker{min-width:125px;width:138px;min-height:42px;font-size:15px!important;}
    .etc-v29-filter{font-size:12px!important;background:var(--e-blue-wash)!important;border:0!important;color:var(--e-blue)!important;border-radius:10px!important;padding:9px!important;min-height:36px!important;}
    .etc-v29-filter[aria-pressed=true]{background:var(--e-blue)!important;color:white!important;}
    .etc-v29-dim{opacity:.28!important;}.etc-v29-highlight{box-shadow:inset 0 0 0 2px var(--e-blue)!important;}
    .etc-v29-approved .etc-calendar-tag{color:var(--e-green)!important;}
    .etc-v29-returned .etc-calendar-tag{color:var(--e-red)!important;}
    .etc-v29-pending .etc-calendar-tag{color:var(--e-blue)!important;}
    .etc-v29-reminders{padding:12px 15px 18px;border-top:1px solid var(--e-line);}
    .etc-v29-reminders h3{font-size:16px;margin:8px 0;}.etc-v29-reminders p{font-size:12px;color:var(--e-muted);line-height:1.5;}
    .etc-v29-reminder-row{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:13px 0;padding:10px;border-radius:10px;background:var(--e-soft);font-size:12px;}
    .etc-v29-reminder-row>span{flex:1;min-width:90px;}.etc-v29-reminder-row input[type=time]{max-width:110px;min-height:36px;font-size:12px!important;}
    .etc-v29-reminder-row select{width:85px;min-height:36px;font-size:12px!important;}.etc-v29-reminder-row small{display:block;width:100%;color:var(--e-muted);}
    @media(min-width:720px){.etc-v29-summary-grid{grid-template-columns:repeat(4,minmax(0,1fr));}}
  `;(document.head||document.documentElement).appendChild(style);
})();
