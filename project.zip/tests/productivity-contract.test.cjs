const fs=require('node:fs');const assert=require('node:assert/strict');
const main=fs.readFileSync('EStaffingTimeCard/Resources/e-staffing-native-v4.6.js','utf8');
const productivity=fs.readFileSync('EStaffingTimeCard/Resources/productivity.js','utf8');
const swift=fs.readFileSync('EStaffingTimeCard/TimeCardView.swift','utf8');
const project=fs.readFileSync('EStaffingTimeCard.xcodeproj/project.pbxproj','utf8');
for(const code of ['etc-v29-summary','etc-v29-worked','etc-v29-total','etc-v29-empty','etc-v29-unsent'])assert(main.includes(code),code);
for(const code of ['__etcOfficialRecords','window.__etcReceiveDashboard','etc-v29-time-picker','etc-v29-filter','etc-v29-reminder-panel']){
  assert((main+productivity).includes(code),code);
}
for(const code of ['etcProductivityBridge','UNUserNotificationCenter','requestAuthorization','UNCalendarNotificationTrigger','OfficialTimeCardWebView'])assert(swift.includes(code),code);
assert(!swift.includes('DuoCalendarSidebar'),'no second calendar / stateful date navigation');
assert(project.includes('Resources/productivity.js'),'bundled file');
assert(!/\.submit\(|requestSubmit\(/.test(productivity),'no attendance form auto submit');
assert(!productivity.includes("localStorage.setItem('etc-v29-time-template'") && productivity.includes("localStorage.removeItem('etc-v29-time-template'"),'remove prior time saving');
console.log('v2.9 productivity source contract: PASS');
