const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const src=fs.readFileSync('EStaffingTimeCard/Resources/productivity.js','utf8');
const start=src.indexOf('  const parseTime = value => {');
const end=src.indexOf('  // Automatic dashboard refresh',start);
assert(start>0 && end>start,'overtime source found');
const fn=vm.runInNewContext('(()=>{'+src.slice(start,end)+'\nreturn compute;})()',{Date});
const period={start:'2026-10-16',end:'2026-10-31'};
function day(date,hours,rest,status='入力あり'){
  return {date,hours,rest,work:true,leave:false,status};
}
const rows=[
 day('2026-10-16','0900-1700','0'),  // 8:00 -> 0:00
 day('2026-10-19','0900-1800','60'), // 8:00 -> 0:00
 day('2026-10-20','0900-1830','60'), // 8:30 -> 0:30
 day('2026-10-21','0900-1900','1:00'), // 9:00 -> 1:00
 day('2026-10-22','2200-0730','90'), // 8:00 -> 0:00, overnight
 day('2026-10-23','0900-1815','01:00'), // 8:15 -> 0:15
];
const a=fn({...period,days:rows});
assert.equal(a.valid,6);
assert.equal(a.worked,6);
assert.equal(a.overtimeMinutes,105,'30+60+15');
assert.equal(a.minutes,8*60+8*60+8*60+30+9*60+8*60+8*60+15);
assert.equal(a.start,period.start);
assert.equal(a.end,period.end);
const twice=fn({...period,days:[...rows,rows[2]]});
assert.equal(twice.overtimeMinutes,a.overtimeMinutes,'no duplicate date double-counted');
const incomplete=fn({...period,days:[...rows,day('2026-10-26','0900-1800','休憩不明')]});
assert.equal(incomplete.worked,7);
assert.equal(incomplete.valid,6,'unknown break must not be invented');
assert.equal(incomplete.overtimeMinutes,105);
const noWork=fn({...period,days:[{date:'2026-10-27',hours:'',rest:'',work:false,leave:false,status:''}]});
assert.equal(noWork.overtimeMinutes,0);
assert.equal(noWork.valid,0);
// Explicit markers and display columns exist; do not issue any form submission.
const main=fs.readFileSync('EStaffingTimeCard/Resources/e-staffing-native-v4.6.js','utf8');
assert(main.includes('id="etc-v29-overtime"'));
assert(main.includes('今月の前半・後半を確認中')); 
assert(src.includes("set('period',isMonth?`対象："));
assert(src.includes("set('overtime',allParsed?formatMinutes(summary.overtimeMinutes):'—')"));
assert(!src.includes('form.submit(') && !src.includes('requestSubmit('));
console.log('Overtime computed from net workday hours; period shown; incomplete & duplicate records handled: PASS');
