const fs = require('fs');
const vm = require('vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(require('node:path').join(__dirname, '../EStaffingTimeCard/Resources/break-autofill.js'), 'utf8');
function run(initial) {
  class FakeInput { set value(v){this._value=v;} get value(){return this._value;} }
  class Field extends FakeInput {
    constructor(name, value) {super();this.name=name; this.value=value??'';this.listeners={};this.readOnly=false;this.disabled=false;}
    addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
    dispatchEvent(event){for(const fn of this.listeners[event.type]||[])fn(event);}
    closest(s){return s==='.etc-form-card'?container:null;}
  }
  const container={append(){}};
  const fields={startTime:new Field('startTime',initial.start||''),endTime:new Field('endTime',initial.end||''),rstTime:new Field('rstTime',initial.rest||'')};
  const form={dataset:{},querySelector:(s)=>fields[s.match(/name="([^"]+)"/)[1]]};
  const doc={querySelector:s=>s==='form[name="TMSINP01ActionForm"]'?form:null,createElement(tag){return {className:'',textContent:'',type:'',listeners:{},setAttribute(){},append(){},addEventListener(t,f){this.listeners[t]=f},click(){this.listeners.click?.();}}},head:{appendChild(){}}};
  const sandbox={document:doc,location:{hostname:'m.e-staffing.ne.jp',pathname:'/s/TMSINP01/'},HTMLInputElement:FakeInput,Event:class{constructor(type,detail){this.type=type;this.bubbles=detail?.bubbles}}};
  vm.runInNewContext(source,sandbox);
  return fields;
}
for(const [start,end,expected] of [
 ['09:00','15:00','0'],['0900','1501','45'],['0900','1700','45'],['0900','1730','60'],
 ['2200','0600','45'],['0900','1800','60']
]){
 const fields=run({start,end}); assert.equal(fields.rstTime.value,expected,`${start}-${end}`);
}
let f=run({start:'09:00',end:'17:30',rest:'90'});assert.equal(f.rstTime.value,'90','existing break preserved');
f=run({start:'09:00',end:'17:30'});f.rstTime.value='75';f.rstTime.dispatchEvent({type:'input'});f.endTime.value='18:30';f.endTime.dispatchEvent({type:'input'});assert.equal(f.rstTime.value,'75','manual change protected');
f=run({start:'09:00',end:'17:30'});f.endTime.value='16:00';f.endTime.dispatchEvent({type:'change'});assert.equal(f.rstTime.value,'45','auto-generated value recalculated');
f=run({start:'09:00',end:'17:30'});f.endTime.value='99:00';f.endTime.dispatchEvent({type:'input'});assert.equal(f.rstTime.value,'','invalidated auto value cleared');
console.log('Break autofill scenarios: PASS');
