const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../EStaffingTimeCard');
const view=fs.readFileSync(path.join(root,'TimeCardView.swift'),'utf8');
const screens=fs.readFileSync(path.join(root,'NativeScreens.swift'),'utf8');
const toolbar=view.match(/ToolbarItemGroup\(placement: \.bottomBar\) \{([\s\S]*?)\n\s{20}\}/);
assert(toolbar,'toolbar is present');
const destinations=[...toolbar[1].matchAll(/nativeDestination\("([^"]+)"/g)].map(m=>m[1]);
assert.deepEqual(destinations,['home','daily','close','settings']);
assert(!toolbar[1].includes('Button {'),'No extra toolbar buttons');
assert(view.includes('navigation.isVisible && !navigation.sheetOpen'), 'settings keeps toolbar');
assert(view.includes('let selected = navigation.nativeSettingsOpen ? destination == "settings"'));
assert(view.includes('navigation.nativeReminderHandler ='));
for(const keyword of ['Section("外観")','Section("給与計算")','Section("通知")','Section("iPhone Duo")','Section("アカウントとプライバシー")','Section("アプリ情報")']) {
  if(!screens.includes(keyword)) {
    // SwiftUI Section with header syntax is equivalent.
    assert(screens.includes(keyword.replace('Section("','Text("')) || screens.includes(keyword), keyword);
  }
}
assert(screens.includes('CredentialVault.delete()'));
assert(screens.includes('isPresented: $confirmDelete'));
assert(screens.includes('model.updateNativeReminder('));
const calendar=screens.match(/struct NativeClosingMonthCalendar:[\s\S]*?struct NativeClosingScreen/)[0];
assert(calendar.includes('private var slotCount'));
assert(calendar.includes('ForEach(0..<(slotCount / 7)'));
assert(calendar.includes('let day = week * 7 + column - month.firstWeekday + 1'));
assert(calendar.includes('if (1...month.days).contains(day)'));
assert(calendar.includes('calendarDay(day)'));
assert(calendar.includes('closing-day-\\(day)'));
assert(!calendar.includes('LazyVGrid'));
for (const [year,month] of [[2026,10],[2026,2],[2026,11],[2027,1],[2028,2],[2027,5],[2026,6]]){
 const days=new Date(Date.UTC(year,month,0)).getUTCDate();
 const first=new Date(Date.UTC(year,month-1,1)).getUTCDay();
 const slots=Math.ceil((first+days)/7)*7;
 const found=[];
 for(let week=0;week<slots/7;week++) for(let col=0;col<7;col++){
  const day=week*7+col-first+1;
  if(day>=1&&day<=days)found.push(day);
 }
 assert.deepEqual(found,Array.from({length:days},(_,i)=>i+1),`${year}-${month} full month including 1-6`);
}
assert(screens.includes('.id("closing-month-\\(model.calendarMonth)'));
console.log('Native 4-tab toolbar, native settings + notifications, all calendar days: PASS');
