const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const root='EStaffingTimeCard/Resources/';
const holidays=fs.readFileSync(root+'japan-holidays.js','utf8');
const productivity=fs.readFileSync(root+'productivity.js','utf8');
const native=fs.readFileSync(root+'e-staffing-native-v4.6.js','utf8');
const swift=fs.readFileSync('EStaffingTimeCard/TimeCardView.swift','utf8');
const context={window:{},Date,console};vm.runInNewContext(holidays,context);
const holiday=context.window.__etcJapanHolidayName;
for(const [date,name] of [['2026-10-12','スポーツの日'],['2026-09-22','国民の休日'],['2026-05-06','振替休日'],['2027-03-22','振替休日'],['2027-09-23','秋分の日'],['2026-10-29','']]){
 assert.equal(holiday(date),name,date);
}
const start=productivity.indexOf('  const parseTime =');
const end=productivity.indexOf('  // Automatic dashboard refresh',start);
assert(start>0&&end>start);
const compute=vm.runInNewContext('(()=>{'+productivity.slice(start,end)+'\nreturn compute;})()',context);
const rows=[
 {date:'2026-10-12',work:false,leave:false,hours:'',rest:'',status:''},// holiday
 {date:'2026-10-13',work:false,leave:false,hours:'',rest:'',status:''},// ordinary weekday
 {date:'2026-10-14',work:true,leave:false,hours:'0900-1830',rest:'60',status:''}
];
const result=compute({start:'2026-10-01',end:'2026-10-15',days:rows});
assert.equal(result.empty,1,'holiday must not count as missing');
assert.equal(result.worked,1);
assert.equal(result.overtimeMinutes,30);
assert(swift.includes('struct NativeCalendarSidebar'),'read-only native split');
assert(swift.includes('OfficialTimeCardWebView(navigation: navigation)'),'single official view');
assert(swift.includes('func openCalendarDate('),'safe same-WKWebView calendar action');
assert(swift.includes('window.__etcOpenCalendarDate?.'),'native day uses current official DOM hook');
assert(swift.includes('case "calendarSnapshot":'),'sanitized snapshot bridge');
assert(productivity.includes('window.__etcReceiveMonthlyCalendar = rows =>'),'calendar refresh');
assert(native.includes('const sameMonth ='),'month wide coverage');
assert(!native.includes('etc-v29-status-note'),'remove verbose dashboard footnote');
console.log('Japanese holidays, missing days, overtime, one-WebView read-only 2-pane: PASS');
