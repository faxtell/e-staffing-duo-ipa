import Foundation

@main struct ShiftForecastTests {
    static func main() {
        assert(ShiftEndForecast.endTime(startHHmm: "0900", netMinutes: 450, breakMinutes: 60) == "17:30")
        assert(ShiftEndForecast.endTime(startHHmm: "0900", netMinutes: 450, breakMinutes: 45) == "17:15")
        assert(ShiftEndForecast.endTime(startHHmm: "0900", netMinutes: 450, breakMinutes: 90) == "18:00")
        assert(ShiftEndForecast.endTime(startHHmm: "2330", netMinutes: 450, breakMinutes: 60) == "翌日 08:00")
        assert(ShiftEndForecast.endTime(startHHmm: "0915", netMinutes: 465, breakMinutes: 75) == "18:15")
        assert(ShiftEndForecast.endTime(startHHmm: "2460", netMinutes: 450, breakMinutes: 60) == nil)
        assert(ShiftEndForecast.endTime(startHHmm: "abc0", netMinutes: 450, breakMinutes: 60) == nil)
        assert(ShiftEndForecast.endTime(startHHmm: "0900", netMinutes: -1, breakMinutes: 60) == nil)
        assert(ShiftEndForecast.endTime(startHHmm: "0900", netMinutes: 450, breakMinutes: 300) == nil)
        print("Shift end forecast arithmetic and input validation: PASS")
    }
}
