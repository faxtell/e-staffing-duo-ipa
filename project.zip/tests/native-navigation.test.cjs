const assert = require('node:assert/strict');
const fs = require('node:fs');
const view = fs.readFileSync('EStaffingTimeCard/TimeCardView.swift', 'utf8');
const js = fs.readFileSync('EStaffingTimeCard/Resources/e-staffing-native-v4.6.js', 'utf8');
for (const [name, system] of [['home','house'],['daily','calendar'],['close','checkmark.rectangle'],['settings','gearshape']]) {
  assert(view.includes(`nativeDestination("${name}",`), `Missing ${name} nav`);
  assert(view.includes(`symbol: "${system}"`), `Missing ${system} symbol`);
}
assert(view.includes('ToolbarItemGroup(placement: .bottomBar)'), 'Not system toolbar');
assert(view.includes('NavigationStack {'), 'Not native navigation container');
assert(!view.includes('GlassEffectContainer('), 'Custom bar still used');
assert(!view.includes('.padding(.trailing, compactPortrait'), 'WebView still narrowed');
assert(js.includes('#etc-native-nav { display:none !important; }'), 'Old web navbar not hidden');
assert(!js.includes('padding-bottom:calc(104px'), 'Old huge empty footer');
console.log('Native system toolbar source contract: PASS');
