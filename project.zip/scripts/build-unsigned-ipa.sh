#!/usr/bin/env bash
# GitHub Actions macOS arm64 runner: build unsigned IPA for later personal signing.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT="$ROOT/EStaffingTimeCard.xcodeproj"
OUT="$ROOT/BuildOutput"
IPA="$OUT/EStaffingTimeCard-Duo-iOS27.1-unsigned.ipa"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$OUT"

if [[ ! -d "$PROJECT" ]]; then
  echo "Missing Xcode project: $PROJECT" >&2
  exit 1
fi

VER="$(xcrun --sdk iphoneos --show-sdk-version)"
if [[ "$VER" != "27.1" ]]; then
  echo "Refusing to build with SDK $VER; exact SDK 27.1 required" >&2
  exit 1
fi

set -o pipefail
xcodebuild \
  -project "$PROJECT" \
  -scheme EStaffingTimeCard \
  -configuration Release \
  -sdk iphoneos27.1 \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$TMP/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  build 2>&1 | tee "$OUT/build.log"

APP="$TMP/DerivedData/Build/Products/Release-iphoneos/EStaffingTimeCard.app"
if [[ ! -d "$APP" ]]; then
  echo "Build did not produce $APP" >&2
  exit 1
fi

PLIST="$APP/Info.plist"
DTSDK="$(/usr/libexec/PlistBuddy -c 'Print :DTSDKName' "$PLIST")"
if [[ "$DTSDK" != "iphoneos27.1" ]]; then
  echo "Incorrect built SDK in Info.plist: $DTSDK" >&2
  exit 1
fi

mkdir -p "$TMP/Payload"
ditto "$APP" "$TMP/Payload/EStaffingTimeCard.app"
rm -f "$IPA"
(
  cd "$TMP"
  ditto -c -k --keepParent Payload "$IPA"
)

/usr/bin/unzip -tq "$IPA" >/dev/null
[[ -s "$IPA" ]] || { echo 'Unsigned IPA was empty' >&2; exit 1; }
echo "Created: $IPA"
echo 'This IPA is UNSIGNED and requires signing before installation.'
