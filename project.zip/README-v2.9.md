# e-staffing for iPhone Duo v2.9 — productivity + adaptive two-pane

Changes:
1. Dashboard: Today, workdays, estimated hours, weekdays with no recorded hours. All data is drawn from the official closing-period page **after you visit it**; never asserts live unpaid/uncleared status from unknown data. Estimated hours are calculated only when valid work spans and rest minutes are present; otherwise dash is shown. No personal attendance data persisted for the dashboard.
2. On an unfolded Duo with a width >=700 points, the app places an independently persistent SwiftUI month calendar to the left of the original WKWebView form. The calendar comes from official day links in the closing-period page. On first use, open Closing Application to load those links. Folded/compact mode remains a single pane.
3. Daily page has native WebKit time pickers linked to the original HHMM fields, quick-recall and explicit save of preferred hours (only the two times saved to localStorage), and the prior safe break assistant. None of these submit automatically.
4. Officially labelled statuses are color-coded. The "weekdays without recorded hours" calendar filter is **reference only** and may include holidays, days not covered by a work schedule, or days with some unrecognized statuses.
5. User-initiated local notifications: weekday reminders and a monthly closing-day reminder via UNUserNotificationCenter. They remind the user to *check* the official system and do not claim that entries/applications are actually missing. Notification authorization is requested only when enabled by user.

Privacy / safety:
- No attendance forms or applications are submitted without explicit user action.
- Day-specific official links live in RAM; not stored on disk.
- Existing Keychain and persistent WebView configurations remain unchanged.
- No app password/OTP/tokens stored by the new productivity assistant.
- Preview images are **design mockups**, not actual Duo hardware captures, and example figures are fictitious.

Validation:
- `node --check` for each resource JS
- `node tests/productivity-contract.test.cjs` and existing source tests
- Playwright mock UI tests (offline)
- GitHub Actions Xcode 27.1 SDK signed-off compile; IPA unsigned.
