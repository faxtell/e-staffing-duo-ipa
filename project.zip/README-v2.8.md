# e-staffing Duo v2.8 — native system navigation

## v2.7 からの変更

- **重要:** 手作りの右側GlassEffectカプセルを廃止し、`NavigationStack` の `ToolbarItemGroup(placement: .bottomBar)` に移行。
- iPhone Duo（外側・内側横向き）は iOS 27.1 の標準の縦ツールバーへ自動配置。内側縦向きは標準の横バー。
- ネイティブバーはWebViewの**外側**のシステム予約領域に入り、前面カメラ／ステータスバーを回避。余白68ptのWebView縮小を削除。
- メニューの文字とSF Symbolsを `Label` で指定。縦ツールバーではiOSがアイコンのみ表示、VoiceOver/オーバーフローには名称を保持。
- アプリ内WebViewは同一インスタンスを維持。タブ選択で公式サイト内リンクをクリックし、Cookie・Keychain・ログインセッションを引き継ぐ。
- 設定シート表示・ログイン画面ではツールバーを非表示。
- v2.7の休憩計算・自動ログイン・締め申請カレンダーを維持。

## テストについて

GitHub Actions `xcode-27` でXcode 27.1 SDKを使った署名なしiOSアプリのコンパイルをチェックする。
iPhone Duoの実機における見た目やタップ領域はまだ確認していないため、動作確認後に調整が必要な場合あり。

参考: https://developer.apple.com/design/human-interface-guidelines/designing-for-iphone-duo
