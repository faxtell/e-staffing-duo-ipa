# e-staffing Duo v2.9.1 — stateful navigation hotfix

- **Removed** the v2.9 split-page native SwiftUI date calendar from daily and closing pages. One persistent WKWebView is now the only form/navigation surface. This avoids bypassing the official application's stateful navigation with replayed cached date URLs.
- The **monthly calendar remains on the closing-application page** in Duo-wide mode, but is read-only. To open a date, tap **一覧表示** and use the original official link in the source table. The original form/table/submission paths are preserved.
- The **previous time save & recall controls** have been removed, and the old local `etc-v29-time-template` value is cleared on first next load of any official page. The standard time input picker remains.
- Prevent native toolbar taps from requesting the already active page and suppress repeated taps during page transitions. Native back-forward swipe is disabled to reduce browser-history request replay. Home back link in the site remains available.
- Still included: Face ID auto-login, official closing calendar, dashboard, rest-time assistant (manual editable), color-coded statuses, and opt-in reminders.
- Official website may reject session transitions for other reasons; a successful offline build does not prove the third-party server will accept every route. If the existing page is already displaying an unauthorized-operation error, sign in again using the official link.
- No automatic attendance submission.

To build: GitHub Actions SDK 27.1 workflow; release IPA remains unsigned and must be signed before installation. Install over old app with compatible signing to preserve cookies/Keychain access.
