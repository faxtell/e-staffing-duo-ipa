# e-staffing Duo v2.9.2 — single-WebView navigation + automatic dashboard refresh

## Fixed

- Removed the problematic split calendar/daily editing feature from v2.9; **one WKWebView now owns every official page and form**. Closing-page month calendar remains as a read-only view; switch to **一覧表示** to tap the official date link.
- Removed previous-time save/recall buttons and deleted their local preference on first launch. iOS time picker and safe break-length suggestions remain.
- Avoid repeat navigations when already on the destination and disable browser-back gesture to avoid server-side state replay.

## Automatic dashboard data collection

- Once **per app launch**, after the authenticated staff menu successfully loads, the same WKWebView clicks the existing official **締め申請** link, reads the records from that page, and returns by clicking the existing **ホーム** link. This is **sequential in-page navigation**, not a hidden iframe or a parallel HTTP request. It may briefly display the closing page while updating.
- No attendance information is fabricated or submitted; only read-only records are used to calculate overview totals, with missing/unknown values shown as unknown.
- If the official session, navigation, or page parsing fails, the app does not retry repeatedly. The user may open the closing page manually. The third-party service may reject automated movements as well; real-device/service testing is required.
- No background polling. No persistence of raw attendance rows, credentials, session tokens or official URLs.

## Build

The project is built using the existing `faxtell/e-staffing-duo-ipa` private repository and GitHub Actions `xcode-27` image, explicitly checking for iOS 27.1 SDK. The output IPA is unsigned. Preserve Bundle ID `jp.personal.timecard.ios` and compatible signing to update existing app data.
