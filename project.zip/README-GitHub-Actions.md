# e-staffing for iPhone Duo — iOS 27.1 SDK 無署名IPA

macOS / Xcode を手元に用意せず、GitHub Actionsの `xcode-27` ランナーで **Xcode 27.1 / iOS 27.1 SDKを指定**して `.ipa` を作成します。

ベース: e-staffing for iPhone Duo **v2.5 AutoLogin**（Face ID等での本人確認後の自動ログイン、保存済み資格情報のKeychain利用、Duo用UIと勤怠カレンダー）。

## 初回セットアップ（GitHubウェブ画面だけでOK）

1. GitHubで**Private（非公開）**のリポジトリを新規作成。
2. 本ZIPを解凍し、フォルダ内の **`EStaffingTimeCard/`、`EStaffingTimeCard.xcodeproj/`、`.github/`、`scripts/` とこのREADME** をリポジトリのルートにアップロードする。`.github` はドットから始まる隠しフォルダなので、フォルダごとコミットできるGitクライアントやWorkを推奨。
3. `main` ブランチへコードをプッシュすると自動的にビルドが始まる。再実行時はGitHubの `Actions` → `Build iPhone Duo IPA (iOS 27.1)` → `Run workflow` でも実行可能。
4. 実行が成功したら、その実行画面の `Artifacts` から `EStaffingTimeCard-Duo-iOS27.1-unsigned` をダウンロードする。
5. Artifactsで得たZIPを解凍すると、`EStaffingTimeCard-Duo-iOS27.1-unsigned.ipa` が入っている。
6. IPAは**未署名**なので、iPhoneにインストールする前に正規の証明書等で署名する。上書き更新の場合、既存のBundle Identifierと署名アクセスグループの互換性が必要。

## 保護・検査

- `xcode-27` のApple Siliconランナーを使用。
- `/Applications/Xcode_27.1.app/Contents/Developer` を指定。
- SDKが**正確に27.1**でなければ失敗として止める。
- `xcodebuild ... -sdk iphoneos27.1` で Release / 実機向けをビルド。
- `CODE_SIGNING_ALLOWED=NO` でApple Developer証明書や実機登録なしでビルド。
- 生成されたアプリの `Info.plist` に記録される `DTSDKName` も検査。
- アーティファクト保管期間は7日。ビルド失敗時はログも取得可能。

## 注意

- GitHub Actionsが完了するまではIPAは未生成です。GitHubへのアップロード・実行にはGitHubアカウントが必要です。
- これは未署名IPA生成用。インストールには別途署名が必要です。
- e-staffingアカウントのユーザーIDやパスワードはGitHub Secretsなどへ登録しないでください。アプリ上で設定したログイン情報はKeychain保存を想定しています。
- 本ZIPはソースとワークフローであり、iPhone Duo実機での最終動作は未検証です。
- XcodeプロジェクトのBundle Identifierは `jp.personal.timecard.ios`。既存アプリのIdentifierが違う場合は、更新前に `EStaffingTimeCard.xcodeproj/project.pbxproj` 内で合わせてください。
